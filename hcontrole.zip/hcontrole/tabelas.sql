-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.6.27


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema `test-controle`
--

CREATE DATABASE IF NOT EXISTS `test-controle`;
USE `test-controle`;

--
-- Definition of table `bairros`
--

DROP TABLE IF EXISTS `bairros`;
CREATE TABLE `bairros` (
  `idbairro` int(10) NOT NULL,
  `bairros` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `bairros`
--

--
-- Definition of table `consumo`
--

DROP TABLE IF EXISTS `consumo`;
CREATE TABLE `consumo` (
  `idconsumo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codpasta` int(10) unsigned NOT NULL,
  `ano` int(10) unsigned NOT NULL,
  `1` int(10) NOT NULL DEFAULT '0',
  `2` int(10) NOT NULL DEFAULT '0',
  `3` int(10) NOT NULL DEFAULT '0',
  `4` int(10) NOT NULL DEFAULT '0',
  `5` int(10) NOT NULL DEFAULT '0',
  `6` int(10) NOT NULL DEFAULT '0',
  `7` int(10) NOT NULL DEFAULT '0',
  `8` int(10) NOT NULL DEFAULT '0',
  `9` int(10) NOT NULL DEFAULT '0',
  `10` int(10) NOT NULL DEFAULT '0',
  `11` int(10) NOT NULL DEFAULT '0',
  `12` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idconsumo`)
) ENGINE=InnoDB AUTO_INCREMENT=7424 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `consumo`
--


--
-- Definition of table `empenho`
--

DROP TABLE IF EXISTS `empenho`;
CREATE TABLE `empenho` (
  `idempenho` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codsecretaria` int(10) unsigned NOT NULL,
  `codund` int(10) unsigned NOT NULL,
  `ano` int(10) unsigned NOT NULL,
  `dotacao` varchar(41) COLLATE utf8_unicode_ci NOT NULL DEFAULT '00.000.00.000.0000.0.000.000000.00.000000',
  `ficha` int(10) unsigned NOT NULL,
  `num_empenho` int(10) unsigned NOT NULL,
  `valor_inicial` decimal(11,2) NOT NULL DEFAULT '1000.00',
  `emp_suplementar1` int(11) DEFAULT NULL,
  `valor_suplementar1` decimal(11,2) DEFAULT NULL,
  `valor_anulacao1` decimal(11,2) DEFAULT NULL,
  `emp_suplementar2` int(11) DEFAULT NULL,
  `valor_suplementar2` decimal(11,2) DEFAULT NULL,
  `valor_anulacao2` decimal(11,2) DEFAULT NULL,
  `emp_suplementar3` int(10) DEFAULT NULL,
  `valor_suplementar3` decimal(11,2) DEFAULT NULL,
  `valor_anulacao3` decimal(11,2) DEFAULT NULL,
  `emp_suplementar4` int(10) DEFAULT NULL,
  `valor_suplementar4` decimal(11,2) DEFAULT NULL,
  `valor_anulacao4` decimal(11,2) DEFAULT NULL,
  `emp_suplementar5` int(11) DEFAULT NULL,
  `valor_suplementar5` decimal(11,2) DEFAULT NULL,
  `valor_anulacao5` decimal(11,2) DEFAULT NULL,
  `emp_suplementar6` int(11) DEFAULT NULL,
  `valor_suplementar6` decimal(11,2) DEFAULT NULL,
  `valor_anulacao6` decimal(11,2) DEFAULT NULL,
  PRIMARY KEY (`idempenho`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `empenho`
--

--
-- Definition of table `imovel`
--

DROP TABLE IF EXISTS `imovel`;
CREATE TABLE `imovel` (
  `idcad` int(10) unsigned NOT NULL,
  `numhidro` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `codtipoprop` int(10) unsigned NOT NULL,
  `proprietario` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `denomina` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `codlogradouro` int(10) unsigned NOT NULL,
  `numero` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `codbairro` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idcad`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `imovel`
--

--
-- Definition of table `info`
--

DROP TABLE IF EXISTS `info`;
CREATE TABLE `info` (
  `idinfo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codinfo` int(10) unsigned NOT NULL,
  `dia` datetime NOT NULL,
  `info` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Info',
  PRIMARY KEY (`idinfo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `info`
--

--
-- Definition of table `pagamento`
--

DROP TABLE IF EXISTS `pagamento`;
CREATE TABLE `pagamento` (
  `idpgto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codsec` int(10) unsigned NOT NULL,
  `codund` int(10) unsigned NOT NULL,
  `ano` int(10) unsigned NOT NULL,
  `1` decimal(11,2) DEFAULT NULL,
  `2` decimal(11,2) DEFAULT NULL,
  `3` decimal(11,2) DEFAULT NULL,
  `4` decimal(11,2) DEFAULT NULL,
  `5` decimal(11,2) DEFAULT NULL,
  `6` decimal(11,2) DEFAULT NULL,
  `7` decimal(11,2) DEFAULT NULL,
  `8` decimal(11,2) DEFAULT NULL,
  `9` decimal(11,2) DEFAULT NULL,
  `10` decimal(11,2) DEFAULT NULL,
  `11` decimal(11,2) DEFAULT NULL,
  `12` decimal(11,2) DEFAULT NULL,
  PRIMARY KEY (`idpgto`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pagamento`
--

--
-- Definition of table `pasta`
--

DROP TABLE IF EXISTS `pasta`;
CREATE TABLE `pasta` (
  `idpasta` int(4) NOT NULL AUTO_INCREMENT,
  `numcad` int(8) DEFAULT NULL,
  `codsec` int(3) DEFAULT NULL,
  `codund` int(2) DEFAULT NULL,
  `codref` int(1) DEFAULT NULL,
  `at2013` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2014` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2015` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2016` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2017` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2018` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2019` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2020` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2021` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2022` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2023` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2024` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2025` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2026` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2027` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2028` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2029` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  `at2030` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Inativo',
  PRIMARY KEY (`idpasta`)
) ENGINE=InnoDB AUTO_INCREMENT=1022 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pasta`
--

--
-- Definition of table `referencia`
--

DROP TABLE IF EXISTS `referencia`;
CREATE TABLE `referencia` (
  `idref` int(10) NOT NULL,
  `referencia` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `referencia`
--

--
-- Definition of table `ruas`
--

DROP TABLE IF EXISTS `ruas`;
CREATE TABLE `ruas` (
  `idrua` int(10) NOT NULL,
  `ruas` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idrua`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `ruas`
--

--
-- Definition of table `secretarias`
--

DROP TABLE IF EXISTS `secretarias`;
CREATE TABLE `secretarias` (
  `idsecretaria` int(10) NOT NULL,
  `secretarias` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `secretarias`
--

--
-- Definition of table `tipoprop`
--

DROP TABLE IF EXISTS `tipoprop`;
CREATE TABLE `tipoprop` (
  `id` int(10) NOT NULL,
  `tipo` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tipoprop`
--

--
-- Definition of table `unidades`
--

DROP TABLE IF EXISTS `unidades`;
CREATE TABLE `unidades` (
  `id` int(10) NOT NULL,
  `unidade` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `unidades`
--

--
-- Definition of table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `usuario` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `senha` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `nivel` int(1) unsigned NOT NULL DEFAULT '1',
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `cadastro` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  KEY `nivel` (`nivel`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `usuarios`
--

/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` (`id`,`nome`,`usuario`,`senha`,`email`,`nivel`,`ativo`,`cadastro`) VALUES 
 (1,'Administrador Teste','admin','d033e22ae348aeb5660fc2140aec35850c4da997','admin@demo.com.br',2,1,'2022-08-25 09:04:46'),
 (2,'Usuário Teste','demo','89e495e7941cf9e40e6980d14a16bf023ccd4c91','usuario@demo.com.br',1,1,'2022-08-25 09:06:01'),
 (3,'Teste de Cadastro','teste','2e6f9b0d5885b6010f9167787445617f553a735f','teste@teste.com',1,1,'2022-11-08 13:59:00');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;


--
-- Definition of table `valores`
--

DROP TABLE IF EXISTS `valores`;
CREATE TABLE `valores` (
  `idvalor` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codpasta` int(10) unsigned NOT NULL,
  `ano` int(10) unsigned NOT NULL,
  `1` decimal(10,2) NOT NULL DEFAULT '0.00',
  `2` decimal(10,2) NOT NULL DEFAULT '0.00',
  `3` decimal(10,2) NOT NULL DEFAULT '0.00',
  `4` decimal(10,2) NOT NULL DEFAULT '0.00',
  `5` decimal(10,2) NOT NULL DEFAULT '0.00',
  `6` decimal(10,2) NOT NULL DEFAULT '0.00',
  `7` decimal(10,2) NOT NULL DEFAULT '0.00',
  `8` decimal(10,2) NOT NULL DEFAULT '0.00',
  `9` decimal(10,2) NOT NULL DEFAULT '0.00',
  `10` decimal(10,2) NOT NULL DEFAULT '0.00',
  `11` decimal(10,2) NOT NULL DEFAULT '0.00',
  `12` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`idvalor`)
) ENGINE=InnoDB AUTO_INCREMENT=7424 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `valores`
--

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
