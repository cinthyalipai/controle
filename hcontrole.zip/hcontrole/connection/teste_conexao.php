<?php
$banco = "test-controle";
$usuario = "root";
$senha = "";
$hostname = "localhost";
$conn = mysqli_connect($hostname,$usuario,$senha); 
mysqli_select_db($conn, $banco) or die( "Não foi possível conectar ao banco MySQL");
if (!$conn) {echo "Não foi possível conectar ao banco MySQL."; exit;}
else {echo "Conexão Realizada com Sucesso.";}
mysqli_close($conn);
?>