<?php
    include ('connection/conexao.php');
    include ('restrito.php');
    echo "<a href='logout.php'>Logout</a>";
?>
<head>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
    <table class="imgposition" border=1>
        <th colspan="3">
            Selecione o menu desejado
        </th>
        <tr>
            <td><a href="semae/index.php"><img src="img/gota_dagua.jpg" height="150" width="150"></a></td>
            <td><a href="#"><img src="img/cadastro_dados.jpg" height="150" width="150"></a></td>
            <td><a href="reinf/index.html"><img src="img/sped_reinf.jpeg" height="150" width="150"></a></td>
        </tr>
    </table>
</body>