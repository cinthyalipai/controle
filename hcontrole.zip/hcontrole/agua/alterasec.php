<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');


$idpasta=$_GET['idpasta'];
$ano=$_GET['ano'];

$sqlsec = "SELECT p.idpasta, p.numcad, s.secretarias, u.unidade, r.referencia, p.at$ano
            FROM pasta p, secretarias s, unidades u, referencia r
            WHERE s.idsecretaria = p.codsec AND
            u.id = p.codund AND
            r.idref = p.codref AND
            p.idpasta = '$idpasta'";   
$resultsec= mysqli_query($conn, $sqlsec);   
$row = mysqli_fetch_array($resultsec);
$tiposec = mysqli_query($conn, "SELECT idsecretaria, secretarias FROM secretarias");
$tipound = mysqli_query($conn, "SELECT id, unidade FROM unidades");
$tiporef = mysqli_query($conn, "SELECT idref, referencia FROM referencia");


echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

echo "<table border='1' cellpading='20' cellspacing='20'>";
    echo "<tr>";
        echo "<td align='center'><b> Atualizacao de Responsabilidade pelo Predio </b>";
            echo "<form name='atualizacao de imovel' method='post' action='#'>";
                echo "<table cellpading='10' cellspacing='10'>";
                    echo"<tr>";
                        echo "<td>Cadastro Semae:</td><td>";echo $row['numcad']; echo "</td>";
                                                    echo "<td><input name='numcad' type='hidden' value=" ;echo $row['numcad']; echo "></td>";
                                                    echo "<td><input name='idpasta' type='hidden' value="; echo $row['idpasta']; echo "></td>";
					 echo "</tr>";
					 echo "<tr>";
						echo "<td>Ano: </td>"; echo "<td>" .$ano. "</td>";
                    echo "</tr>";
                    echo "<tr>";
                        echo "<td>Secretaria</td>";
                        echo "<td>"; echo "De: ".$row ['secretarias']; echo "</td>";
                        echo "<td><input name='secretarias' type='hidden' value="; echo $row['secretarias']; echo "</td>";
						echo "Para: ";
						echo "<select name='nome_sec'>"; 
                        echo" <option>Selecione Secretaria</option>"; 
                            while($secretaria = mysqli_fetch_array($tiposec)) 
                                {  
                                echo "<option value='".$secretaria['idsecretaria']."'>"; echo $secretaria['secretarias'];
                                echo "</option>"; 
                                } 
                    echo "</select>";
                    echo "</tr>";
                    echo "<tr>";
                        echo "<td>Unidade</td>";
                        echo "<td>"; echo "De: ".$row ['unidade']; echo "</td>";
                        echo "<td><input name='unidade' type='hidden' value="; echo $row['unidade']; echo "</td>";
						echo "Para: ";
						echo "<select name='nome_und'>"; 
                        echo "<option>Selecione Unidade</option>"; 
                            while($unidade = mysqli_fetch_array($tipound)) 
                            { 
                                echo "<option value='".$unidade['id']."'>";echo $unidade['unidade'];
                                echo"</option>"; 
                            } 
                    echo "</select>";
                    echo "</tr>";
                    echo "<tr>";
                        echo "<td>Referência</td>";
                        echo "<td>"; echo "De: ".$row ['referencia']; echo "</td>";
                        echo "<td><input name='referencia' type='hidden' value="; echo $row['referencia']; echo "</td>";
						echo "Para: ";
						echo "<select name='nome_ref'>"; 
                        echo "<option>Selecione Referência</option>"; 
                        	while($referencia = mysqli_fetch_array($tiporef)) 
                        	{  
                            echo "<option value='".$referencia['idref']."'>";echo $referencia['referencia'];
                            echo "</option>"; 
                        	} 
                    echo "</select>";
                    echo "</tr>";
					echo "<tr>";
						echo"<td align='left'><input type='submit' name='Submit' value='Alterar'>";
 					echo "</tr>";
                echo "</table>";
            echo "</form>";
        echo "</td>";
    echo "</tr>";
echo "</table>";


If (isset($_POST['numcad'])){

$newcad = $_POST['numcad'];
$newsec = $_POST['nome_sec'];
$newund = $_POST['nome_und'];
$newref = $_POST['nome_ref'];


//altera secretaria para inativo
$sql_sucess_alt="UPDATE pasta SET
                 at$ano = 'Inativo'
                 WHERE idpasta='".$idpasta."' ";
$result_sucess_alt = mysqli_query($conn, $sql_sucess_alt);


//insere nova secretaria
$sql_sucess_new_sec = "INSERT INTO pasta (numcad, codsec, codund, codref, at$ano) VALUES ('".$newcad."','".$newsec."','".$newund."','".$newref."', 'Ativo')";
$result_sucess_new_sec = mysqli_query($conn, $sql_sucess_new_sec);

// cadastra em consumo e valores
$hoje=date('Y-m-d');
$anocad = date('Y');

$consultaid = "SELECT max(idpasta) from pasta where numcad=$newcad";
$result_consultaid = mysqli_query($conn, $consultaid);
$num_id = mysqli_fetch_row($result_consultaid);
$cod_pasta = $num_id[0];

$sql3 = "INSERT INTO valores (codpasta, ano) VALUES ('".$cod_pasta."','".$anocad."')";
$result3 = mysqli_query($conn, $sql3);

$sql4 = "INSERT INTO consumo (codpasta, ano) VALUES ('".$cod_pasta."','".$anocad."')";
$result4 = mysqli_query($conn, $sql4);

$sql5 = "INSERT INTO info (codinfo, dia, info) VALUES ('".$newcad."','".$hoje."', 'Cadastro alterado pelo usuário ".$_SESSION['UsuarioNome']."')";
$result5 = mysqli_query($conn, $sql5);


If ($result_sucess_alt AND $result_sucess_new_sec)
	{
   		echo "<h3>Dados alterados com sucesso</h3>";

	die();
	}
}
