<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

$id_cad=$_POST['cadastro']; 
$hidrometro=$_POST['hidrometro']; 
$cod_prop=$_POST['tipo_loc']; 
$nome_prop=$_POST['nome_prop']; 
$denomina=$_POST['denomina']; 
$endereco=$_POST['nome_rua'];
$numero=$_POST['num_predio']; 
$bairro=$_POST['nome_bairro'];

$cod_sec=$_POST['nome_sec'];
$cod_und=$_POST['nome_und'];
$ref=$_POST['nome_ref'];
$at_2013 = isset($_POST['at2013']) ? 'Ativo' : 'Inativo'; 
$at_2014 = isset($_POST['at2014']) ? 'Ativo' : 'Inativo'; 
$at_2015 = isset($_POST['at2015']) ? 'Ativo' : 'Inativo'; 
$at_2016 = isset($_POST['at2016']) ? 'Ativo' : 'Inativo'; 
$at_2017 = isset($_POST['at2017']) ? 'Ativo' : 'Inativo'; 
$at_2018 = isset($_POST['at2018']) ? 'Ativo' : 'Inativo'; 
$at_2019 = isset($_POST['at2019']) ? 'Ativo' : 'Inativo'; 
$at_2020 = isset($_POST['at2020']) ? 'Ativo' : 'Inativo'; 
$at_2021 = isset($_POST['at2021']) ? 'Ativo' : 'Inativo'; 
$at_2022 = isset($_POST['at2022']) ? 'Ativo' : 'Inativo'; 
$at_2023 = isset($_POST['at2023']) ? 'Ativo' : 'Inativo'; 
$at_2024 = isset($_POST['at2024']) ? 'Ativo' : 'Inativo'; 
$at_2025 = isset($_POST['at2025']) ? 'Ativo' : 'Inativo'; 
$at_2026 = isset($_POST['at2026']) ? 'Ativo' : 'Inativo'; 
$at_2027 = isset($_POST['at2027']) ? 'Ativo' : 'Inativo'; 
$at_2028 = isset($_POST['at2028']) ? 'Ativo' : 'Inativo'; 
$at_2029 = isset($_POST['at2029']) ? 'Ativo' : 'Inativo'; 
$at_2030 = isset($_POST['at2030']) ? 'Ativo' : 'Inativo'; 


$consulta = "SELECT idcad FROM imovel WHERE idcad = '$id_cad'";
$verificaconsulta = mysqli_query($conn, $consulta);
$verificaconsulta2 = mysqli_num_rows($verificaconsulta);

if ($verificaconsulta2 !=0){ //se o cadastro já existir
	echo "<head>";
	echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />";
	echo "<title> Cadastro já Existente! </title>";
	echo "</head>";


	echo "<body>";
    echo"<br>";echo"<br>";echo"<br>";echo"<br>";echo"<br>";
    echo "<h3 align='center'>Cadastro já existente</h3>";
    echo "<P align='center'> Dados do Imóvel: </P>";
    echo"<br>";echo"<br>";
	echo"<br>";echo"<br>";
	echo "<table border=1>";
        echo "<th colspan='8'>Informações do Imóvel</th>";
        echo "<tr>";
            echo "<td>Numero Cadastro</td>";
            echo "<td>Numero Hidrometro</td>";
            echo "<td>Tipo de Contrato</td>";
            echo "<td>Nome Proprietário</td>";
            echo "<td>Denominação Imóvel</td>";
            echo "<td>Logradouro</td>";
            echo "<td>Numero</td>";
            echo "<td>Bairro</td>";
			echo "</tr>";

			$cadexist = "SELECT i.idcad, i.numhidro, p.tipo, i.proprietario, i.denomina, r.ruas, i.numero, b.bairros
			FROM imovel i, tipoprop p, ruas r, bairros b
			WHERE p.id = i.codtipoprop AND
				r.idrua = i.codlogradouro AND
				b.idbairro = i.codbairro AND
				i.idcad = $id_cad";
			$result_cadexist = mysqli_query($conn, $cadexist);
			while($rows_cadexist = mysqli_fetch_array($result_cadexist))
			{
			$id_cad=$rows_cadexist['idcad']; 
			$hidrometro=$rows_cadexist['numhidro']; 
			$cod_prop=$rows_cadexist['tipo']; 
			$nome_prop=$rows_cadexist['proprietario']; 
			$denomina=$rows_cadexist['denomina']; 
			$endereco=$rows_cadexist['ruas'];
			$numero=$rows_cadexist['numero']; 
			$bairro=$rows_cadexist['bairros'];
			echo "<tr>";
			echo "<td>".$rows_cadexist['idcad']."</td>";
			echo "<td>".$rows_cadexist['numhidro']."</td>";
			echo "<td>".$rows_cadexist['tipo']."</td>";
			echo "<td>".$rows_cadexist['proprietario']."</td>";
			echo "<td>".$rows_cadexist['denomina']."</td>";
			echo "<td>".$rows_cadexist['ruas']."</td>";
			echo "<td>".$rows_cadexist['numero']."</td>";
			echo "<td>".$rows_cadexist['bairros']."</td>";
			echo "</tr>";
			}
			echo "</table>";

			echo"<br>";echo"<br>";
    echo "<table border='2'>";
        echo "<th colspan='21'>Secretaria Responsável</th>";
        echo "<tr>";
		echo "<td>Secretaria</td>";
		echo "<td>Unidade</td>";
		echo "<td>Referência Cobrança</td>";
		echo "<td>2013</td>";
		echo "<td>2014</td>";
		echo "<td>2015</td>";
		echo "<td>2016</td>";
		echo "<td>2017</td>";
		echo "<td>2018</td>";
		echo "<td>2019</td>";
		echo "<td>2020</td>";
		echo "<td>2021</td>";
		echo "<td>2022</td>";
		echo "<td>2023</td>";
		echo "<td>2024</td>";
		echo "<td>2025</td>";
		echo "<td>2026</td>";
		echo "<td>2027</td>";
		echo "<td>2028</td>";
		echo "<td>2029</td>";
		echo "<td>2030</td>";
        echo "</tr>";

		$secexist = "SELECT s.secretarias, u.unidade, r.referencia, p.at2013 as '2013', p.at2014 as '2014', p.at2015 as '2015', p.at2016 as '2016',p.at2017 as '2017', p.at2018 as '2018',
		  p.at2019 as '2019', p.at2020 as '2020',p.at2021 as '2021', p.at2022 as '2022', p.at2023 as '2023', p.at2024 as '2024',p.at2025 as '2025', p.at2026 as '2026',
		  p.at2027 as '2027', p.at2028 as '2028',p.at2029 as '2029', p.at2030 as '2030'
  		  			FROM pasta p, secretarias s, unidades u,referencia r
 		  			WHERE p.codsec = s.idsecretaria AND
		  					p.codund = u.id AND
		  					p.codref = r.idref AND
		  					p.numcad = $id_cad
		  				ORDER BY p.idpasta";
		 		$result_secexist = mysqli_query($conn, $secexist);
		 		while($rows_secexist = mysqli_fetch_array($result_secexist)){
		 	$cod_sec=['secretarias'];
		 	$cod_und=['unidade'];
		 	$ref=['referencia'];
		 	$at_2013 = ['2013']; 
		 	$at_2014 = ['2014']; 
		 	$at_2015 = ['2015'];  
		 	$at_2016 = ['2016']; 
		 	$at_2017 = ['2017']; 
		 	$at_2018 = ['2018']; 
		 	$at_2019 = ['2019']; 
		 	$at_2020 = ['2020'];  
		 	$at_2021 = ['2021']; 
		 	$at_2022 = ['2022']; 
		 	$at_2023 = ['2023'];  
		 	$at_2024 = ['2024'];  
		 	$at_2025 = ['2025']; 
		 	$at_2026 = ['2026'];  
		 	$at_2027 = ['2027'];  
		 	$at_2028 = ['2028'];  
		 	$at_2029 = ['2029'];  
		 	$at_2030 = ['2030'];
		 	echo "<tr>";
		 	echo "<td>".$rows_secexist['secretarias']."</td>";
		 	echo "<td>".$rows_secexist['unidade']."</td>";
		 	echo "<td>".$rows_secexist['referencia']."</td>";
		 	echo "<td>".$rows_secexist['2013']."</td>";
		 	echo "<td>".$rows_secexist['2014']."</td>";
		 	echo "<td>".$rows_secexist['2015']."</td>";
		 	echo "<td>".$rows_secexist['2016']."</td>";
		 	echo "<td>".$rows_secexist['2017']."</td>";
		 	echo "<td>".$rows_secexist['2018']."</td>";
		 	echo "<td>".$rows_secexist['2019']."</td>";
		 	echo "<td>".$rows_secexist['2020']."</td>";
		 	echo "<td>".$rows_secexist['2021']."</td>";
		 	echo "<td>".$rows_secexist['2022']."</td>";
		 	echo "<td>".$rows_secexist['2023']."</td>";
		 	echo "<td>".$rows_secexist['2024']."</td>";
		 	echo "<td>".$rows_secexist['2025']."</td>";
		 	echo "<td>".$rows_secexist['2026']."</td>";
		 	echo "<td>".$rows_secexist['2027']."</td>";
		 	echo "<td>".$rows_secexist['2028']."</td>";
		 	echo "<td>".$rows_secexist['2029']."</td>";
		 	echo "<td>".$rows_secexist['2030']."</td>";
		 	echo "</tr>"; 
		 }
		echo "</table>";
}

else // se o cadastro for novo

{
$sql="INSERT INTO imovel (idcad, numhidro, codtipoprop, proprietario,denomina, codlogradouro, numero, codbairro)
	VALUES ('".$id_cad."','".$hidrometro."','".$cod_prop."','".$nome_prop."','".$denomina."','".$endereco."','".$numero."','".$bairro."')";
$result = mysqli_query($conn, $sql);

$sql2="INSERT INTO pasta (numcad, codsec, codund, codref, at2013, at2014, at2015, at2016, at2017, at2018, at2019, at2020, at2021, at2022, at2023, at2024, at2025, at2026, at2027, at2028, at2029, at2030)
	VALUES ('".$id_cad."','".$cod_sec."','".$cod_und."','".$ref."','".$at_2013."','".$at_2014."','".$at_2015."','".$at_2016."','".$at_2017."','".$at_2018."','".$at_2019."','".$at_2020."','".$at_2021."','".$at_2022."','".$at_2023."','".$at_2024."','".$at_2025."','".$at_2026."','".$at_2027."','".$at_2028."','".$at_2029."','".$at_2030."')";
$result2 = mysqli_query($conn, $sql2);

$consultaid = "SELECT max(idpasta) from pasta where numcad=$id_cad";
$result_consultaid = mysqli_query($conn, $consultaid);
$num_id = mysqli_fetch_row($result_consultaid);
$cod_pasta = $num_id[0];

$hoje=date("Y-m-d");
$anocad = date('Y');

$sql3 = "INSERT INTO valores (codpasta, ano) VALUES ('".$cod_pasta."','".$anocad."')";
$result3 = mysqli_query($conn, $sql3);

$sql4 = "INSERT INTO consumo (codpasta, ano) VALUES ('".$cod_pasta."','".$anocad."')";
$result4 = mysqli_query($conn, $sql4);

$sql5 = "INSERT INTO info (codinfo, dia, info) VALUES ('".$id_cad."','".$hoje."', 'Cadastro realizado pelo usuário ".$_SESSION['UsuarioNome']."')";
$result5 = mysqli_query($conn, $sql5);

echo "<head>";
	echo "<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />";
	echo "<title> Novo Cadastro Realizado </title>";
	echo "</head>";


	echo "<body>";
    echo"<br>";echo"<br>";echo"<br>";echo"<br>";echo"<br>";
    echo "<h3 align='center'>Imóvel Cadastrado com Sucesso</h3>";
    echo "<P align='center'> Dados do Novo Imóvel: </P>";
    echo"<br>";echo"<br>";
	echo "<table border=1>";
        echo "<th colspan='8'>Informações do Imóvel</th>";
        echo "<tr>";
            echo "<td>Numero Cadastro</td>";
            echo "<td>Numero Hidrometro</td>";
            echo "<td>Tipo de Contrato</td>";
            echo "<td>Nome Proprietário</td>";
            echo "<td>Denominação Imóvel</td>";
            echo "<td>Logradouro</td>";
            echo "<td>Numero</td>";
            echo "<td>Bairro</td>";
			echo "</tr>";

	$cadsucesso = "SELECT i.idcad, i.numhidro, p.tipo, i.proprietario, i.denomina, r.ruas, i.numero, b.bairros
                    FROM imovel i, tipoprop p, ruas r, bairros b
                    WHERE p.id = i.codtipoprop AND
                        r.idrua = i.codlogradouro AND
                        b.idbairro = i.codbairro AND
                        i.idcad = $id_cad";
    $result_cadsucesso = mysqli_query($conn, $cadsucesso);
	while($rows_cadsucesso = mysqli_fetch_array($result_cadsucesso))
{
    $id_cad=$rows_cadsucesso['idcad']; 
    $hidrometro=$rows_cadsucesso['numhidro']; 
    $cod_prop=$rows_cadsucesso['tipo']; 
    $nome_prop=$rows_cadsucesso['proprietario']; 
    $denomina=$rows_cadsucesso['denomina']; 
    $endereco=$rows_cadsucesso['ruas'];
    $numero=$rows_cadsucesso['numero']; 
    $bairro=$rows_cadsucesso['bairros'];
	echo "<tr>";
	echo "<td>".$rows_cadsucesso['idcad']."</td>";
	echo "<td>".$rows_cadsucesso['numhidro']."</td>";
    echo "<td>".$rows_cadsucesso['tipo']."</td>";
	echo "<td>".$rows_cadsucesso['proprietario']."</td>";
	echo "<td>".$rows_cadsucesso['denomina']."</td>";
	echo "<td>".$rows_cadsucesso['ruas']."</td>";
	echo "<td>".$rows_cadsucesso['numero']."</td>";
	echo "<td>".$rows_cadsucesso['bairros']."</td>";
	echo "</tr>";
}
	echo "</table>";

	echo"<br>";echo"<br>";
    echo "<table border='2'>";
        echo "<th colspan='21'>Secretaria Responsável</th>";
        echo "<tr>";
		echo "<td>Secretaria</td>";
		echo "<td>Unidade</td>";
		echo "<td>Referência Cobrança</td>";
		echo "<td>2013</td>";
		echo "<td>2014</td>";
		echo "<td>2015</td>";
		echo "<td>2016</td>";
		echo "<td>2017</td>";
		echo "<td>2018</td>";
		echo "<td>2019</td>";
		echo "<td>2020</td>";
		echo "<td>2021</td>";
		echo "<td>2022</td>";
		echo "<td>2023</td>";
		echo "<td>2024</td>";
		echo "<td>2025</td>";
		echo "<td>2026</td>";
		echo "<td>2027</td>";
		echo "<td>2028</td>";
		echo "<td>2029</td>";
		echo "<td>2030</td>";
        echo "</tr>";
		$secnovo = "SELECT p.idpasta, s.secretarias, u.unidade, r.referencia, p.at2013 as '2013', p.at2014 as '2014', p.at2015 as '2015', p.at2016 as '2016',p.at2017 as '2017', p.at2018 as '2018',
		p.at2019 as '2019', p.at2020 as '2020',p.at2021 as '2021', p.at2022 as '2022', p.at2023 as '2023', p.at2024 as '2024',p.at2025 as '2025', p.at2026 as '2026',
		p.at2027 as '2027', p.at2028 as '2028',p.at2029 as '2029', p.at2030 as '2030'
					FROM pasta p, secretarias s, unidades u,referencia r
					WHERE p.codsec = s.idsecretaria AND
							p.codund = u.id AND
							p.codref = r.idref AND
							p.numcad = $id_cad AND
							p.idpasta = (select max(idpasta) from pasta where numcad=$id_cad)
					ORDER BY p.idpasta";
			$result_secnovo = mysqli_query($conn, $secnovo);
			while($rows_secnovo = mysqli_fetch_array($result_secnovo)){
		 	$cod_sec=['secretarias'];
		 	$cod_und=['unidade'];
		 	$ref=['referencia'];
		 	$at_2013 = ['2013']; 
		 	$at_2014 = ['2014']; 
		 	$at_2015 = ['2015'];  
		 	$at_2016 = ['2016']; 
		 	$at_2017 = ['2017']; 
		 	$at_2018 = ['2018']; 
		 	$at_2019 = ['2019']; 
		 	$at_2020 = ['2020'];  
		 	$at_2021 = ['2021']; 
		 	$at_2022 = ['2022']; 
		 	$at_2023 = ['2023'];  
		 	$at_2024 = ['2024'];  
		 	$at_2025 = ['2025']; 
		 	$at_2026 = ['2026'];  
		 	$at_2027 = ['2027'];  
		 	$at_2028 = ['2028'];  
		 	$at_2029 = ['2029'];  
		 	$at_2030 = ['2030'];
		 	echo "<tr>";
		 	echo "<td>".$rows_secnovo['secretarias']."</td>";
		 	echo "<td>".$rows_secnovo['unidade']."</td>";
		 	echo "<td>".$rows_secnovo['referencia']."</td>";
		 	echo "<td>".$rows_secnovo['2013']."</td>";
		 	echo "<td>".$rows_secnovo['2014']."</td>";
		 	echo "<td>".$rows_secnovo['2015']."</td>";
		 	echo "<td>".$rows_secnovo['2016']."</td>";
		 	echo "<td>".$rows_secnovo['2017']."</td>";
		 	echo "<td>".$rows_secnovo['2018']."</td>";
		 	echo "<td>".$rows_secnovo['2019']."</td>";
		 	echo "<td>".$rows_secnovo['2020']."</td>";
		 	echo "<td>".$rows_secnovo['2021']."</td>";
		 	echo "<td>".$rows_secnovo['2022']."</td>";
		 	echo "<td>".$rows_secnovo['2023']."</td>";
		 	echo "<td>".$rows_secnovo['2024']."</td>";
		 	echo "<td>".$rows_secnovo['2025']."</td>";
		 	echo "<td>".$rows_secnovo['2026']."</td>";
		 	echo "<td>".$rows_secnovo['2027']."</td>";
		 	echo "<td>".$rows_secnovo['2028']."</td>";
		 	echo "<td>".$rows_secnovo['2029']."</td>";
		 	echo "<td>".$rows_secnovo['2030']."</td>";
		 	echo "</tr>"; 
		 }
		echo "</table>";

}

?>