<?php
include ('../connection/conexao.php');
include ('../semae/barramenu.php');

echo "<br><br>";

$numcad = $_POST['numcad'];
$dia = $_POST['dia'];
$descricao = $_POST['descricao'];


$armazena = "INSERT INTO info (codinfo, dia, info) VALUES ('".$numcad."','".$dia."','".$descricao."')";
$resultarmazena = mysqli_query($conn, $armazena);

if ($resultarmazena)
    echo "Dados armazenados com sucesso";

?>