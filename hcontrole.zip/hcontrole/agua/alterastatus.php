<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');
?>

<br><br>
<form name="status" method="POST" action="alterastatus.php">
    <table >
        <tr>
            <td>Tipo de Alteração:</td>
            <td>
                <select name="tipo_alt">
                    <option value="1">Por Cadastro</option>
                    <option value="2">Listagem Completa</option>
                </select>
            <td colspan='2' align='right'><input type="submit" name="enviar" value="Pesquisar"></td>
        </tr>
    </table>
</form>

<?php

if (isset($_POST['tipo_alt'])){

    if ($_POST['tipo_alt'] == 1)
    {
        $altera = $_POST['tipo_alt'];
    ?>
    <br><br><br><br><br>
    <form action = 'gravastatus.php' method='POST'>
        <fieldset>
            <legend>Insira Cadastro a Ser Alterado: </legend>
                <br>
                    <label for="cadastro">Número do Cadastro</label>
                    <input type="number" name="cadastro" id="cadastro" maxlength="8" />
                    <input type="hidden" name="alteracao" id="alteracao" value="<?php echo $altera?>" />
                    <input type="submit" value="Alterar" />
        </fieldset>
    </form>

    <?php
    }

    elseif ($_POST['tipo_alt'] == 2)
    {
        $altera = $_POST['tipo_alt'];
    ?>
    <br><br><br><br><br>
    <form action = 'gravastatus.php' method='POST'>
        <fieldset>
            <legend>Alteração em Lote</legend>
                <br>
                    <label for="lote">Insira o Ano de Referência (ano atual):</label>
                    <input type="number" name="ano" id="ano" maxlength="4" />
                    <input type="hidden" name="alteracao" id="alteracao" value="<?php echo $altera?>"/>
                    <input type="submit" value="Alterar" />
        </fieldset>
    </form>
    
    <?php
    }
}
?>