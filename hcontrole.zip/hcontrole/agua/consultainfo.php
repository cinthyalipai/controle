<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

?>
<head>
    <meta charset="utf-8">
    <title>Pesquisa Por Cadastro</title>
</head>
<body>
<br><br>
<h3> Pesquisa dados gerais por Cadastro </h3>
<br><br>
<form method="POST" action="consultainfo.php">
    Insira Número do Cadastro:<input type="text" name="cadastro" placeholder="Número Cadastro">
    <input type="submit" name="enviar" value="Enviar"> 

<?php

If (isset($_POST['cadastro']))
{
    $cadastro = $_POST['cadastro'];

$sql_imovel = "SELECT i.idcad, i.numhidro, p.tipo, i.proprietario, i.denomina, r.ruas, i.numero, b.bairros
                FROM imovel i, tipoprop p, ruas r, bairros b
                WHERE p.id = i.codtipoprop AND
                    r.idrua = i.codlogradouro AND
                    b.idbairro = i.codbairro AND
                    i.idcad = $cadastro";
$resultado_sqlimovel = mysqli_query($conn, $sql_imovel);
$rows_sqlimovel = mysqli_fetch_array($resultado_sqlimovel);

    echo "<br><br><br><br>";
    echo"<table border='1'>";
    echo"<th colspan =7>Cadastro nº: ".$cadastro."</th>";
    echo"<tr>";
        echo"<td><b>Hidrometro</b></td>";              
        echo"<td><b>Tipo Imovel</b></td>";
        echo"<td><b>Proprietario</b></td>";
        echo"<td><b>Denominacao</b></td>";
        echo"<td><b>Logradouro</b></td>";
        echo"<td><b>Numero</b></td>";
        echo"<td><b>Bairro</b></td>";
    echo"</tr>";

    if($rows_sqlimovel >0)
    {
        $hidrometro=$rows_sqlimovel['numhidro']; 
        $cod_prop=$rows_sqlimovel['tipo']; 
        $nome_prop=$rows_sqlimovel['proprietario']; 
        $denomina=$rows_sqlimovel['denomina']; 
        $endereco=$rows_sqlimovel['ruas'];
        $numero=$rows_sqlimovel['numero']; 
        $bairro=$rows_sqlimovel['bairros'];

            do
            {
                echo "<tr>";
                echo "<td>".$rows_sqlimovel['numhidro']."</td>";
                echo "<td>".$rows_sqlimovel['tipo']."</td>";
                echo "<td>".$rows_sqlimovel['proprietario']."</td>";
                echo "<td>".$rows_sqlimovel['denomina']."</td>";
                echo "<td>".$rows_sqlimovel['ruas']."</td>";
                echo "<td>".$rows_sqlimovel['numero']."</td>";
                echo "<td>".$rows_sqlimovel['bairros']."</td>";
                echo "</tr>";
            } while($rows_sqlimovel = mysqli_fetch_array($resultado_sqlimovel));
            echo "</table>";
    }
    
$sql_secretaria = "SELECT s.secretarias, u.unidade, r.referencia, p.at2013 as '2013', p.at2014 as '2014', p.at2015 as '2015', p.at2016 as '2016',p.at2017 as '2017', p.at2018 as '2018',
p.at2019 as '2019', p.at2020 as '2020',p.at2021 as '2021', p.at2022 as '2022', p.at2023 as '2023', p.at2024 as '2024',p.at2025 as '2025', p.at2026 as '2026',
p.at2027 as '2027', p.at2028 as '2028',p.at2029 as '2029', p.at2030 as '2030'
                    FROM pasta p, secretarias s, unidades u,referencia r
                    WHERE p.codsec = s.idsecretaria AND
                            p.codund = u.id AND
                            p.codref = r.idref AND
                            p.numcad = $cadastro
                    ORDER BY p.idpasta";
$resultado_sqlsecretaria = mysqli_query($conn, $sql_secretaria);
$rows_sqlsecretaria = mysqli_fetch_array($resultado_sqlsecretaria);


echo "<br><br><br>";
    echo "<table border='2'>";
        echo "<th colspan='21'>Secretaria Responsável</th>";
        echo "<tr>";
            echo "<td><b>Secretaria</b></td>";
            echo "<td><b>Unidade</b></td>";
            echo "<td><b>Referência Cobrança</b></td>";
            echo "<td><b>2013</b></td>";
            echo "<td><b>2014</b></td>";
            echo "<td><b>2015</b></td>";
            echo "<td><b>2016</b></td>";
            echo "<td><b>2017</b></td>";
            echo "<td><b>2018</b></td>";
            echo "<td><b>2019</b></td>";
            echo "<td><b>2020</b></td>";
            echo "<td><b>2021</b></td>";
            echo "<td><b>2022</b></td>";
            echo "<td><b>2023</b></td>";
            echo "<td><b>2024</b></td>";
            echo "<td><b>2025</b></td>";
            echo "<td><b>2026</b></td>";
            echo "<td><b>2027</b></td>";
            echo "<td><b>2028</b></td>";
            echo "<td><b>2029</b></td>";
            echo "<td><b>2030</b></td>";
        echo "</tr>";

        if ($rows_sqlsecretaria >0)
        {
            $cod_sec=['secretarias'];
		 	$cod_und=['unidade'];
		 	$ref=['referencia'];
		 	$at_2013 = ['2013']; 
		 	$at_2014 = ['2014']; 
		 	$at_2015 = ['2015'];  
		 	$at_2016 = ['2016']; 
		 	$at_2017 = ['2017']; 
		 	$at_2018 = ['2018']; 
		 	$at_2019 = ['2019']; 
		 	$at_2020 = ['2020'];  
		 	$at_2021 = ['2021']; 
		 	$at_2022 = ['2022']; 
		 	$at_2023 = ['2023'];  
		 	$at_2024 = ['2024'];  
		 	$at_2025 = ['2025']; 
		 	$at_2026 = ['2026'];  
		 	$at_2027 = ['2027'];  
		 	$at_2028 = ['2028'];  
		 	$at_2029 = ['2029'];  
		 	$at_2030 = ['2030'];

            do
            {
            echo "<tr>";
                echo "<td>".$rows_sqlsecretaria['secretarias']."</td>";
                echo "<td>".$rows_sqlsecretaria['unidade']."</td>";
                echo "<td>".$rows_sqlsecretaria['referencia']."</td>";
                echo "<td>".$rows_sqlsecretaria['2013']."</td>";
                echo "<td>".$rows_sqlsecretaria['2014']."</td>";
                echo "<td>".$rows_sqlsecretaria['2015']."</td>";
                echo "<td>".$rows_sqlsecretaria['2016']."</td>";
                echo "<td>".$rows_sqlsecretaria['2017']."</td>";
                echo "<td>".$rows_sqlsecretaria['2018']."</td>";
                echo "<td>".$rows_sqlsecretaria['2019']."</td>";
                echo "<td>".$rows_sqlsecretaria['2020']."</td>";
                echo "<td>".$rows_sqlsecretaria['2021']."</td>";
                echo "<td>".$rows_sqlsecretaria['2022']."</td>";
                echo "<td>".$rows_sqlsecretaria['2023']."</td>";
                echo "<td>".$rows_sqlsecretaria['2024']."</td>";
                echo "<td>".$rows_sqlsecretaria['2025']."</td>";
                echo "<td>".$rows_sqlsecretaria['2026']."</td>";
                echo "<td>".$rows_sqlsecretaria['2027']."</td>";
                echo "<td>".$rows_sqlsecretaria['2028']."</td>";
                echo "<td>".$rows_sqlsecretaria['2029']."</td>";
                echo "<td>".$rows_sqlsecretaria['2030']."</td>";
		 	echo "</tr>"; 
            }
            while($rows_sqlsecretaria = mysqli_fetch_array($resultado_sqlsecretaria));

            echo "</table>";
        }		
		 		
$sql_consumo = "SELECT s.secretarias, c.ano,
                c.1 as cons_jan, v.1 as val_jan, c.2 as cons_fev, v.2 as val_fev, c.3 as cons_mar, v.3 as val_mar, c.4 as cons_abr, v.4 as val_abr,
                c.5 as cons_mai, v.5 as val_mai, c.6 as cons_jun, v.6 as val_jun, c.7 as cons_jul, v.7 as val_jul, c.8 as cons_ago, v.8 as val_ago,
                c.9 as cons_set, v.9 as val_set, c.10 as cons_out, v.10 as val_out, c.11 as cons_nov, v.11 as val_nov, c.12 as cons_dez, v.12 as val_dez
                FROM consumo c, valores v, pasta p, secretarias s
                WHERE p.idpasta = c.idconsumo AND
                        p.idpasta = v.idvalor AND
                        p.codsec = s.idsecretaria AND
                        p.numcad = $cadastro
                ORDER BY v.ano";	
$resultado_sqlconsumo = mysqli_query($conn, $sql_consumo);
$rows_sqlconsumo = mysqli_fetch_array($resultado_sqlconsumo);

        echo "<br><br><br>";
        echo "<table border='2'>";
            echo "<th colspan='26'>Consumo Mensal</th>";
            echo "<tr>";
                echo "<td><b>Secretaria</b></td>";
                echo "<td><b>Ano</b></td>";
                echo "<td><b>Jan m³</b></td>";
                echo "<td><b>Jan R$</b></td>";
                echo "<td><b>Fev m³</b></td>";
                echo "<td><b>Fev R$</b></td>";
                echo "<td><b>Mar m³</b></td>";
                echo "<td><b>Mar R$</b></td>";
                echo "<td><b>Abr m³</b></td>";
                echo "<td><b>Abr R$</b></td>";
                echo "<td><b>Mai m³</b></td>";
                echo "<td><b>Mai R$</b></td>";
                echo "<td><b>Jun m³</b></td>";
                echo "<td><b>Jun R$</b></td>";
                echo "<td><b>Jul m³</b></td>";
                echo "<td><b>Jul R$</b></td>";
                echo "<td><b>Ago m³</b></td>";
                echo "<td><b>Ago R$</b></td>";
                echo "<td><b>Set m³</b></td>";
                echo "<td><b>Set R$</b></td>";
                echo "<td><b>Out m³</b></td>";
                echo "<td><b>Out R$</b></td>";
                echo "<td><b>Nov m³</b></td>";
                echo "<td><b>Nov R$</b></td>";
                echo "<td><b>Dez m³</b></td>";
                echo "<td><b>Dez R$</b></td>";
            echo "</tr>";

            if ($rows_sqlconsumo >0)
            {
                $sec=['secretarias'];
                $ano=['ano'];
                $cons_jan = ['cons_jan'];
                $val_jan = ['val_jan']; 
                $cons_fev = ['cons_fev']; 
                $val_fev = ['val_fev'];  
                $cons_mar = ['cons_mar']; 
                $val_mar = ['val_mar']; 
                $cons_abr = ['cons_abr']; 
                $val_abr = ['val_abr']; 
                $cons_mai = ['cons_mai'];  
                $val_mai = ['val_mai']; 
                $cons_jun = ['cons_jun']; 
                $val_jun = ['val_jun'];  
                $cons_jul = ['cons_jul'];  
                $val_jul = ['val_jul']; 
                $cons_ago = ['cons_ago'];  
                $val_ago = ['val_ago'];  
                $cons_set = ['cons_set'];  
                $val_set = ['val_set'];  
                $cons_out = ['cons_out'];
                $val_out = ['val_out']; 
                $cons_nov = ['cons_nov'];
                $val_nov = ['val_nov']; 
                $cons_dez = ['cons_dez'];
                $val_dez = ['val_dez']; 
    
                do
                {
                echo "<tr>";
                    echo "<td>".$rows_sqlconsumo['secretarias']."</td>";
                    echo "<td>".$rows_sqlconsumo['ano']."</td>";
                    echo "<td>".$rows_sqlconsumo['cons_jan']."</td>";
                    echo "<td>".$rows_sqlconsumo['val_jan']."</td>";
                    echo "<td>".$rows_sqlconsumo['cons_fev']."</td>";
                    echo "<td>".$rows_sqlconsumo['val_fev']."</td>";
                    echo "<td>".$rows_sqlconsumo['cons_mar']."</td>";
                    echo "<td>".$rows_sqlconsumo['val_mar']."</td>";
                    echo "<td>".$rows_sqlconsumo['cons_abr']."</td>";
                    echo "<td>".$rows_sqlconsumo['val_abr']."</td>";
                    echo "<td>".$rows_sqlconsumo['cons_mai']."</td>";
                    echo "<td>".$rows_sqlconsumo['val_mai']."</td>";
                    echo "<td>".$rows_sqlconsumo['cons_jun']."</td>";
                    echo "<td>".$rows_sqlconsumo['val_jun']."</td>";
                    echo "<td>".$rows_sqlconsumo['cons_jul']."</td>";
                    echo "<td>".$rows_sqlconsumo['val_jul']."</td>";
                    echo "<td>".$rows_sqlconsumo['cons_ago']."</td>";
                    echo "<td>".$rows_sqlconsumo['val_ago']."</td>";
                    echo "<td>".$rows_sqlconsumo['cons_set']."</td>";
                    echo "<td>".$rows_sqlconsumo['val_set']."</td>";
                    echo "<td>".$rows_sqlconsumo['cons_out']."</td>";
                    echo "<td>".$rows_sqlconsumo['val_out']."</td>";
                    echo "<td>".$rows_sqlconsumo['cons_nov']."</td>";
                    echo "<td>".$rows_sqlconsumo['val_nov']."</td>";
                    echo "<td>".$rows_sqlconsumo['cons_dez']."</td>";
                    echo "<td>".$rows_sqlconsumo['val_dez']."</td>";
                echo "</tr>"; 
                }
                while($rows_sqlconsumo = mysqli_fetch_array($resultado_sqlconsumo));
                
                echo "</table>";
            }

            echo "<br><br><br>";
            echo "<table border='2'>";
                echo "<th colspan='2'>Informações</th>";
                echo "<tr>";
                    echo "<td><b>Data</b></td>";
                    echo "<td><b>Observação</b></td>";
                echo "</tr>";

            $sql_info = "SELECT f.dia, f.info
                        FROM info f, imovel i
                        WHERE i.idcad = f.codinfo AND
                            f.codinfo = $cadastro
                        ORDER BY f.dia ";
            $resultado_sqlinfo = mysqli_query($conn, $sql_info);
            $rows_sqlinfo = mysqli_fetch_array($resultado_sqlinfo);

            
            if ($rows_sqlinfo > 0)
            {
                $data=['dia'];
                $info=['info'];

                
                do
                {
                echo "<tr>";
                    echo "<td>".$rows_sqlinfo['dia']."</td>";
                    echo "<td>".$rows_sqlinfo['info']."</td>";
                echo "</tr>"; 
                }
                while($rows_sqlinfo = mysqli_fetch_array($resultado_sqlinfo));
            echo "</table>";
            }

}

?>

</body>