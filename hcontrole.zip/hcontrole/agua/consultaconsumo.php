<?php

include ('../connection/conexao.php'); //PRECISA VERIFICAR O ERRO QUE ESTÁ DANDO QUANDO EXISTEM DOIS REGISTROS NO NUM_ROWS, POIS CONTA APENAS UMA DAS LINHAS (NO SELECT POR ANO)
include ('../semae/barramenu.php');
$cadastro = mysqli_query($conn, "SELECT idcad FROM imovel");
?>
<head>
    <meta charset="utf-8">
    <title>Pesquisa Por Cadastro</title>
</head>
<body>
    <br>
    <form name="pesquisa" method="POST" action="">
        <table>
            <th colspan='2'>Consulta de Consumo por Cadastro</th>
            <tr>
                <td>Selecione Cadastro:</td>
                <td><input type="text" name="idcad" id="idcad" maxlength="7" required/></td>
            </tr>
            <tr>
                <td></td>
            </tr>
            <tr>
                <td></td>
            </tr>
            <tr>
                <td>Mes Inicio:</td>
                <td>
                    <select name="mesinic">
                        <option value="1">Janeiro</option>
                        <option value="2">Fevereiro</option>
                        <option value="3">Março</option>
                        <option value="4">Abril</option>
                        <option value="5">Maio</option>
                        <option value="6">Junho</option>
                        <option value="7">Julho</option>
                        <option value="8">Agosto</option>
                        <option value="9">Setembro</option>
                        <option value="10">Outubro</option>
                        <option value="11">Novembro</option>
                        <option value="12">Dezembro</option>
                    </select>
                </td>
                <td>Ano Inicio:</td>
                <td><input type="number" name="anoinic" id="anoinic" maxlength="4" required/></td>
            </tr>
            <tr>
                <td>Mes Fim:</td>
                <td>
                    <select name="mesfim">
                        <option value="1">Janeiro</option>
                        <option value="2">Fevereiro</option>
                        <option value="3">Março</option>
                        <option value="4">Abril</option>
                        <option value="5">Maio</option>
                        <option value="6">Junho</option>
                        <option value="7">Julho</option>
                        <option value="8">Agosto</option>
                        <option value="9">Setembro</option>
                        <option value="10">Outubro</option>
                        <option value="11">Novembro</option>
                        <option value="12">Dezembro</option>
                    </select>
                </td>
                <td>Ano Fim:</td>
                <td><input type="number" name="anofim" id="anofim" maxlength="4" required/></td>
            </tr>
            <tr>
                <td align="right" colspan="2"><input type="submit" value="Pesquisar"></td>
            </tr>
        </table>
    </form>

<?php

if (isset($_POST['idcad']) and isset($_POST['anoinic']) and isset($_POST['anofim']))
{
    $idcad = $_POST['idcad'];
    $mesfim = $_POST['mesfim'];
    $mesinic = $_POST['mesinic'];
    $anoinic = $_POST['anoinic'];
    $anofim = $_POST['anofim'];
    $datainic = $anoinic."-".$mesinic."-01";
    $datafim = $anofim."-".$mesfim."-01";
    $convertinicio = strtotime($datainic);
    $convertfim = strtotime($datafim);
    
        //Para ver as variaveis pesquisadas
        echo "<br><br><br>";
        echo "<table border='2'>";
        echo "<th colspan='5'>Informações Pesquisadas</th>";
        echo "<tr>";
        echo "<td><b>Número Cadastro</b></td>";
        echo "<td><b>Mês Início</b></td>";
        echo "<td><b>Ano Início</b></td>";
        echo "<td><b>Mês Fim</b></td>";
        echo "<td><b>Ano Fim</b></td>";
        echo "<tr>";
        echo "<td align='center'>".$idcad."</td>";
        echo "<td align='center'>".$mesinic."</td>";
        echo "<td align='center'>".$anoinic."</td>";
        echo "<td align='center'>".$mesfim."</td>";
        echo "<td align='center'>".$anofim."</td>";
        echo "</table>";

        if ($convertfim < $convertinicio)
        {
            echo "<br><br><br><h3 align='center'> Ano Inicio deve ser maior que Ano Fim </h3>";
            echo "<br>";
            echo $convertinicio;
            echo "<br>";
            echo $convertfim;
            echo "<br>";
        }
        elseif ($convertfim == $convertinicio)
        {    
            echo "<br><br><br><h3 align='center'> Datas Iguais </h3>"; 
            echo "<br>";
        }    
        else
        
        echo "<br><br><br>";
        echo "<table border='2'>";
        echo "<th colspan='5'>Consumo Mensal</th>";
        echo "<tr>";
        echo "<td><b>Total Meses Avaliado</b></td>";
        echo "<td><b>Consumo no Período</b></td>";
        echo "<td><b>Média de Consumo no Período</b></td>";
        echo "<td><b>Valor Gasto no Período</b></td>";
        echo "<td><b>Média de Gasto no Período</b></td>";
        

        
        $cjaneiro = "SELECT sum(c.1)
                        from consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            c.ano between $anoinic and $anofim";
        $cvalorjaneiro = mysqli_query($conn, $cjaneiro);
        $cresult_janeiro = mysqli_fetch_row($cvalorjaneiro);


        $cfevereiro = "SELECT sum(c.2)
                        from consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            c.ano between $anoinic and $anofim";
        $cvalorfevereiro = mysqli_query($conn, $cfevereiro);
        $cresult_fevereiro = mysqli_fetch_row($cvalorfevereiro);

        $cmarco = "SELECT sum(c.3)
                        from consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            c.ano between $anoinic and $anofim";
        $cvalormarco = mysqli_query($conn, $cmarco);
        $cresult_marco = mysqli_fetch_row($cvalormarco);


        $cabril = "SELECT sum(c.4)
                        from consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            c.ano between $anoinic and $anofim";
        $cvalorabril = mysqli_query($conn, $cabril);
        $cresult_abril = mysqli_fetch_row($cvalorabril);

        $cmaio = "SELECT sum(c.5)
                        from consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            c.ano between $anoinic and $anofim";
        $cvalormaio = mysqli_query($conn, $cmaio);
        $cresult_maio = mysqli_fetch_row($cvalormaio);


        $cjunho = "SELECT sum(c.6)
                        from consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            c.ano between $anoinic and $anofim";
        $cvalorjunho = mysqli_query($conn, $cjunho);
        $cresult_junho = mysqli_fetch_row($cvalorjunho);

        $cjulho = "SELECT sum(c.7)
                        from consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            c.ano between $anoinic and $anofim";
        $cvalorjulho = mysqli_query($conn, $cjulho);
        $cresult_julho = mysqli_fetch_row($cvalorjulho);


        $cagosto = "SELECT sum(c.8)
                        from consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            c.ano between $anoinic and $anofim";
        $cvaloragosto = mysqli_query($conn, $cagosto);
        $cresult_agosto = mysqli_fetch_row($cvaloragosto);

        $csetembro = "SELECT sum(c.9)
                        from consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            c.ano between $anoinic and $anofim";
        $cvalorsetembro = mysqli_query($conn, $csetembro);
        $cresult_setembro = mysqli_fetch_row($cvalorsetembro);


        $coutubro = "SELECT sum(c.10)
                        from consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            c.ano between $anoinic and $anofim";
        $cvaloroutubro = mysqli_query($conn, $coutubro);
        $cresult_outubro = mysqli_fetch_row($cvaloroutubro);

        $cnovembro = "SELECT sum(c.11)
                        from consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            c.ano between $anoinic and $anofim";
        $cvalornovembro = mysqli_query($conn, $cnovembro);
        $cresult_novembro = mysqli_fetch_row($cvalornovembro);


        $cdezembro = "SELECT sum(c.12)
                        from consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            c.ano between $anoinic and $anofim";
        $cvalordezembro = mysqli_query($conn, $cdezembro);
        $cresult_dezembro = mysqli_fetch_row($cvalordezembro);


        $vjaneiro = "SELECT sum(v.1)
                        from valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            v.ano between $anoinic and $anofim";
        $vvalorjaneiro = mysqli_query($conn, $vjaneiro);
        $vresult_janeiro = mysqli_fetch_row($vvalorjaneiro);


        $vfevereiro = "SELECT sum(v.2)
                        from valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            v.ano between $anoinic and $anofim";
        $vvalorfevereiro = mysqli_query($conn, $vfevereiro);
        $vresult_fevereiro = mysqli_fetch_row($vvalorfevereiro);

        $vmarco = "SELECT sum(v.3)
                        from valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            v.ano between $anoinic and $anofim";
        $vvalormarco = mysqli_query($conn, $vmarco);
        $vresult_marco = mysqli_fetch_row($vvalormarco);


        $vabril = "SELECT sum(v.4)
                        from valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            v.ano between $anoinic and $anofim";
        $vvalorabril = mysqli_query($conn, $vabril);
        $vresult_abril = mysqli_fetch_row($vvalorabril);

        $vmaio = "SELECT sum(v.5)
                        from valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            v.ano between $anoinic and $anofim";
        $vvalormaio = mysqli_query($conn, $vmaio);
        $vresult_maio = mysqli_fetch_row($vvalormaio);


        $vjunho = "SELECT sum(v.6)
                        from valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            v.ano between $anoinic and $anofim";
        $vvalorjunho = mysqli_query($conn, $vjunho);
        $vresult_junho = mysqli_fetch_row($vvalorjunho);

        $vjulho = "SELECT sum(v.7)
                        from valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            v.ano between $anoinic and $anofim";
        $vvalorjulho = mysqli_query($conn, $vjulho);
        $vresult_julho = mysqli_fetch_row($vvalorjulho);


        $vagosto = "SELECT sum(v.8)
                        from valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            v.ano between $anoinic and $anofim";
        $vvaloragosto = mysqli_query($conn, $vagosto);
        $vresult_agosto = mysqli_fetch_row($vvaloragosto);

        $vsetembro = "SELECT sum(v.9)
                        from valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            v.ano between $anoinic and $anofim";
        $vvalorsetembro = mysqli_query($conn, $vsetembro);
        $vresult_setembro = mysqli_fetch_row($vvalorsetembro);


        $voutubro = "SELECT sum(v.10)
                        from valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            v.ano between $anoinic and $anofim";
        $vvaloroutubro = mysqli_query($conn, $voutubro);
        $vresult_outubro = mysqli_fetch_row($vvaloroutubro);

        $vnovembro = "SELECT sum(v.11)
                        from valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            v.ano between $anoinic and $anofim";
        $vvalornovembro = mysqli_query($conn, $vnovembro);
        $vresult_novembro = mysqli_fetch_row($vvalornovembro);


        $vdezembro = "SELECT sum(v.12)
                        from valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                            p.numcad = $idcad and
                            v.ano between $anoinic and $anofim";
        $vvalordezembro = mysqli_query($conn, $vdezembro);
        $vresult_dezembro = mysqli_fetch_row($vvalordezembro);

        //soma todo o consumo (coluna do BD)
        $cmix = array_merge($cresult_janeiro, $cresult_fevereiro, $cresult_marco, $cresult_abril, $cresult_maio, $cresult_junho, $cresult_julho, $cresult_agosto, $cresult_setembro, $cresult_outubro, $cresult_novembro, $cresult_dezembro);
        $cmix_sum = array_sum($cmix);

        //soma todo o valor (coluna do BD)
        $vmix = array_merge($vresult_janeiro, $vresult_fevereiro, $vresult_marco, $vresult_abril, $vresult_maio, $vresult_junho, $vresult_julho, $vresult_agosto, $vresult_setembro, $vresult_outubro, $vresult_novembro, $vresult_dezembro);
        $vmix_sum = array_sum ($vmix);


        //consulta para extração do período início consumo
        $sqlconsumoinicio = "SELECT DISTINCT
        (select sum(c.1)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anoinic),
        (select sum(c.2)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anoinic),
        (select sum(c.3)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anoinic),
        (select sum(c.4)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anoinic),
        (select sum(c.5)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anoinic),
        (select sum(c.6)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anoinic),
        (select sum(c.7)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anoinic),
        (select sum(c.8)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anoinic),
        (select sum(c.9)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anoinic),
        (select sum(c.10)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anoinic),
        (select sum(c.11)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anoinic),
        (select sum(c.12)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anoinic)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anoinic";
        $resultado_sqlconsumoinicio = mysqli_query($conn, $sqlconsumoinicio);
        $rows_sqlconsumoinicio = mysqli_fetch_array($resultado_sqlconsumoinicio);
        $retiraconsumoinicio = array_slice($rows_sqlconsumoinicio, ($mesinic*2-2)-24 );
        $somaarrayconsumoinicio = intval(array_sum($retiraconsumoinicio))/2;
        $somaarraytotalconsumoinicio = intval(array_sum($rows_sqlconsumoinicio)/2);

        //consulta para extração do período fim consumo
        $sqlconsumofim = "SELECT DISTINCT
        (select sum(c.1)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anofim),
        (select sum(c.2)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anofim),
        (select sum(c.3)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anofim),
        (select sum(c.4)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anofim),
        (select sum(c.5)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anofim),
        (select sum(c.6)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anofim),
        (select sum(c.7)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anofim),
        (select sum(c.8)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anofim),
        (select sum(c.9)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anofim),
        (select sum(c.10)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anofim),
        (select sum(c.11)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anofim),
        (select sum(c.12)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anofim)
        FROM consumo c, pasta p
        WHERE c.codpasta = p.idpasta and
              p.numcad = $idcad and
              c.ano = $anofim";
        $resultado_sqlconsumofim = mysqli_query($conn, $sqlconsumofim);
        $rows_sqlconsumofim = mysqli_fetch_array($resultado_sqlconsumofim);
        $retiraconsumofim = array_slice($rows_sqlconsumofim, ($mesfim*2)-24);
        $somaarrayconsumofim = intval(array_sum($retiraconsumofim))/2;
        $somaarraytotalconsumofim = intval(array_sum($rows_sqlconsumofim)/2);

        
        //consulta para extração do período início valor
        $sqlvalorinicio = "SELECT DISTINCT
        (select sum(v.1)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anoinic),
        (select sum(v.2)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anoinic),
        (select sum(v.3)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anoinic),
        (select sum(v.4)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anoinic),
        (select sum(v.5)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anoinic),
        (select sum(v.6)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anoinic),
        (select sum(v.7)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anoinic),
        (select sum(v.8)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anoinic),
        (select sum(v.9)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anoinic),
        (select sum(v.10)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anoinic),
        (select sum(v.11)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anoinic),
        (select sum(v.12)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anoinic)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anoinic";
        $resultado_sqlvalorinicio = mysqli_query($conn, $sqlvalorinicio);
        $rows_sqlvalorinicio = mysqli_fetch_array($resultado_sqlvalorinicio);
        $retiravalorinicio = array_slice($rows_sqlvalorinicio, ($mesinic*2-2)-24);
        $somaarrayvalorinicio = floatval(array_sum($retiravalorinicio))/2; //array esta particionado
        $somaarraytotalvalorinicio = floatval(array_sum($rows_sqlvalorinicio)/2); //conta todo o array

        //consulta para extração do período fim valor
        $sqlvalorfim = "SELECT DISTINCT
        (select sum(v.1)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anofim),
        (select sum(v.2)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anofim),
        (select sum(v.3)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anofim),
        (select sum(v.4)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anofim),
        (select sum(v.5)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anofim),
        (select sum(v.6)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anofim),
        (select sum(v.7)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anofim),
        (select sum(v.8)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anofim),
        (select sum(v.9)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anofim),
        (select sum(v.10)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anofim),
        (select sum(v.11)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anofim),
        (select sum(v.12)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anofim)
        FROM valores v, pasta p
        WHERE v.codpasta = p.idpasta and
              p.numcad = $idcad and
              v.ano = $anofim";
        $resultado_sqlvalorfim = mysqli_query($conn, $sqlvalorfim);
        $rows_sqlvalorfim = mysqli_fetch_array($resultado_sqlvalorfim);
        $retiravalorfim = array_slice($rows_sqlvalorfim, ($mesfim*2)-24);
        $somaarrayvalorfim = floatval(array_sum($retiravalorfim))/2;
        $somaarraytotalvalorfim = floatval(array_sum($rows_sqlvalorfim)/2);
       
        // calcula os totais por periodo
        if($anofim == $anoinic)
        {
            $nummeses = $mesfim - $mesinic + 1;

            if ($mesinic == 1 and $mesfim < 12)
                {
                    $consumo = $somaarrayconsumoinicio - $somaarrayconsumofim;
                    $valor = $somaarrayvalorinicio - $somaarrayvalorfim;
                    $mediaconsumo = $consumo/$nummeses;
                    $mediavalor = $valor/$nummeses;
                }
            elseif ($mesinic > 1 and $mesfim == 12)
                {
                    $consumo = $somaarrayconsumofim - ($somaarraytotalconsumoinicio - $somaarrayconsumoinicio);
                    $valor = $somaarrayvalorfim - ($somaarraytotalvalorinicio - $somaarrayvalorinicio);
                    $mediaconsumo = $consumo/$nummeses;
                    $mediavalor = $valor/$nummeses;
                }
            elseif ($mesinic > 1 and $mesfim < 12)
                {
                    $consumo = $somaarrayconsumoinicio - $somaarrayconsumofim;
                    $valor = $somaarrayvalorinicio - $somaarrayvalorfim;
                    $mediaconsumo = $consumo/$nummeses;
                    $mediavalor = $valor/$nummeses;
                }
            elseif ($mesinic == 1 and $mesfim == 12)
                {
                    $consumo = $somaarrayconsumoinicio;
                    $valor = $somaarrayvalorinicio;
                    $mediaconsumo = $consumo/$nummeses;
                    $mediavalor = $valor/$nummeses;
                }

            echo "<tr>";
            echo "<td align='center'>".$nummeses."</td>";
            echo "<td align='center'>".$consumo."</td>";
            echo "<td align='center'>".number_format($mediaconsumo,2,',','')."</td>";
            echo "<td align='center'>".number_format($valor,2,',','')."</td>";
            echo "<td align='center'>".number_format($mediavalor,2,',','')."</td>";
            echo "</table>";

        }
        else
        {
            if ($anofim - $anoinic == 1)
            {
                $anodif = $anofim - $anoinic;
                $nummeses = ($anodif*12);
                $cmesdif = $somaarrayconsumoinicio ;
                $vmesdif = $somaarrayvalorinicio ;
                $consumo = $cmesdif + ($somaarraytotalconsumofim - $somaarrayconsumofim);
                $valor = $vmesdif + ($somaarraytotalvalorfim - $somaarrayvalorfim);
                $mediaconsumo = $consumo/$nummeses;
                $mediavalor = $valor/$nummeses;
            }
            elseif ($anofim - $anoinic > 1)
            {
                if($mesinic == 1 and $mesfim < 12)
                {
                    $anodif = $anofim - $anoinic;
                    $nummeses = ($anodif*12)+($mesfim);
                    $cmesdif = $somaarrayconsumofim ;
                    $vmesdif = $somaarrayvalorfim ;
                    $consumo = $cmix_sum - $cmesdif;
                    $valor = $vmix_sum - $vmesdif;
                    $mediaconsumo = $consumo/$nummeses;
                    $mediavalor = $valor/$nummeses;
                }
                elseif ($mesinic > 1 and $mesfim == 12)
                {
                    $anodif = $anofim - $anoinic;
                    $nummeses = ($anodif*12)+(12-$mesinic+1);
                    $cmesdif = $somaarrayconsumofim - ($somaarraytotalconsumoinicio - $somaarrayconsumoinicio);
                    $vmesdif = $somaarrayvalorfim - ($somaarraytotalvalorinicio - $somaarrayvalorinicio);
                    $consumo = $cmix_sum - $cmesdif;
                    $valor = $vmix_sum - $vmesdif;
                    $mediaconsumo = $consumo/$nummeses;
                    $mediavalor = $valor/$nummeses;
                }
                elseif ($mesinic == 1 and $mesfim == 12)
                {
                    $anodif = $anofim - $anoinic + 1;
                    $nummeses = ($anodif*12);
                    $consumo = $cmix_sum;
                    $valor = $vmix_sum;
                    $mediaconsumo = $consumo/$nummeses;
                    $mediavalor = $valor/$nummeses;
                }
                elseif($mesinic > 1 and $mesfim < 12)
                {
                    $anodif = $anofim - $anoinic - 1;
                    $nummeses = ($anodif*12)+ (12-$mesinic+1) + $mesfim;

                    for ($anotemp=$anoinic + 1; $anotemp < $anofim; $anotemp++)
                    {
                        $sqlconsumotemp = "SELECT DISTINCT
                        (select sum(c.1)
                        FROM consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              c.ano = $anotemp),
                        (select sum(c.2)
                        FROM consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              c.ano = $anotemp),
                        (select sum(c.3)
                        FROM consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              c.ano = $anotemp),
                        (select sum(c.4)
                        FROM consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              c.ano = $anotemp),
                        (select sum(c.5)
                        FROM consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              c.ano = $anotemp),
                        (select sum(c.6)
                        FROM consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              c.ano = $anotemp),
                        (select sum(c.7)
                        FROM consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              c.ano = $anotemp),
                        (select sum(c.8)
                        FROM consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              c.ano = $anotemp),
                        (select sum(c.9)
                        FROM consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              c.ano = $anotemp),
                        (select sum(c.10)
                        FROM consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              c.ano = $anotemp),
                        (select sum(c.11)
                        FROM consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              c.ano = $anotemp),
                        (select sum(c.12)
                        FROM consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              c.ano = $anotemp)
                        FROM consumo c, pasta p
                        WHERE c.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              c.ano = $anotemp";
                        $resultado_sqlconsumotemp = mysqli_query($conn, $sqlconsumotemp);
                        $rows_sqlconsumotemp = mysqli_fetch_array($resultado_sqlconsumotemp);
                        $somaconstemp = intval(array_sum($rows_sqlconsumotemp)/2);

                        $sqlvalortemp = "SELECT DISTINCT
                        (select sum(v.1)
                        FROM valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              v.ano = $anotemp),
                        (select sum(v.2)
                        FROM valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              v.ano = $anotemp),
                        (select sum(v.3)
                        FROM valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              v.ano = $anotemp),
                        (select sum(v.4)
                        FROM valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              v.ano = $anotemp),
                        (select sum(v.5)
                        FROM valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              v.ano = $anotemp),
                        (select sum(v.6)
                        FROM valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              v.ano = $anotemp),
                        (select sum(v.7)
                        FROM valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              v.ano = $anotemp),
                        (select sum(v.8)
                        FROM valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              v.ano = $anotemp),
                        (select sum(v.9)
                        FROM valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              v.ano = $anotemp),
                        (select sum(v.10)
                        FROM valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              v.ano = $anotemp),
                        (select sum(v.11)
                        FROM valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              v.ano = $anotemp),
                        (select sum(v.12)
                        FROM valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              v.ano = $anotemp)
                        FROM valores v, pasta p
                        WHERE v.codpasta = p.idpasta and
                              p.numcad = $idcad and
                              v.ano = $anotemp";
                        $resultado_sqlvalortemp = mysqli_query($conn, $sqlvalortemp);
                        $rows_sqlvalortemp = mysqli_fetch_array($resultado_sqlvalortemp);
                        $somavaltemp = floatval(array_sum($rows_sqlvalortemp)/2);
                           
                        $consumotemp = $somaconstemp;
                        $valortemp = $somavaltemp;
                    }
                    $consumo = $somaarrayconsumoinicio + ($somaarraytotalconsumofim - $somaarrayconsumofim) + $consumotemp;
                    $valor = $somaarrayvalorinicio + ($somaarraytotalvalorfim - $somaarrayvalorfim) + $valortemp;
                    $mediaconsumo = $consumo/$nummeses;
                    $mediavalor = $valor/$nummeses;


                }

            }
            
            echo "<tr>";
            echo "<td align='center'>".$nummeses."</td>";
            echo "<td align='center'>".$consumo."</td>";
            echo "<td align='center'>".number_format($mediaconsumo,'2',',','')."</td>";
            echo "<td align='center'>".number_format($valor,'2',',','')."</td>";
            echo "<td align='center'>".number_format($mediavalor,'2',',','')."</td>";
            echo "</table>";
        }

        
    }
?>

</body>