<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

?>

<form method="POST" action="atualizacad.php">
    Insira Número do Cadastro:<input type="text" name="idcad" placeholder="Número Cadastro"> <br><br>
    Insira Ano para pesquisa:<input type="text" name="ano" placeholder="Ano">
    <input type="submit" name="enviar" value="Enviar"> <br> <br>
    
<?php

    if (empty($_POST['idcad']) and empty($_POST['ano']))

        echo "Inserir dados para a pesquisa";

    elseif (!empty($_POST['idcad']) and empty($_POST['ano']))

        echo "Cadastro ou Ano não informados";

    elseif (empty ($_POST['idcad']) and !empty($_POST['ano']))

        echo "Cadastro ou Ano não informados";

    elseif (!empty($_POST['idcad']) and !empty($_POST['ano'])) 
    { 

     echo "<body>";

     echo"<table border='1'>";
     echo"<tr>";
         echo"<td><b>Cadastro</b></td>";              
         echo"<td><b>Hidrometro</b></td>"; 
         echo"<td><b>Tipo Contrato</b></td>";             
         echo"<td><b>Proprietario Imovel</b></td>";
         echo"<td><b>Nome do Predio</b></td>";
         echo"<td><b>Endereco</b></td>";
         echo"<td><b>Numero</b></td>";          
         echo"<td><b>Bairro</b></td>";
         echo"<td><b>Secretaria</b></td>";
         echo"<td><b>Unidade</b></td>";
         echo"<td><b>Ref Cobrança</b></td>";
         echo"<td><b>Funcionamento</b></td>";
     echo"</tr>";

     $idcad = $_POST['idcad'];
     $ano = $_POST['ano'];

     echo "Cadastro Pesquisado: Todos aqueles que contenham " .$idcad;
     echo "<br>";
     echo "Ano Pesquisado: ".$ano;
     echo "<br>";
     echo "<br>";

 $sql_cad = "SELECT i.idcad, i.numhidro, t.tipo, i.proprietario, i.denomina, r.ruas, i.numero, b.bairros, s.secretarias, u.unidade, f.referencia, p.at$ano as funcionamento
             FROM imovel i, pasta p, tipoprop t, ruas r, bairros b, secretarias s, unidades u, referencia f
             WHERE i.idcad = p.numcad AND
                     t.id = i.codtipoprop AND
                     r.idrua = i.codlogradouro AND
                     b.idbairro = i.codbairro AND
                     s.idsecretaria = p.codsec AND
                     u.id = p.codund AND
                     f.idref = p.codref AND
                     p.at$ano LIKE 'Ativo' AND
                     p.numcad LIKE '%$idcad%'
             ORDER BY p.at$ano ASC, 
                      i.idcad ASC";  
 $resultado_cad = mysqli_query($conn, $sql_cad);
     while($rows_cad = mysqli_fetch_array($resultado_cad))
     {
         $idcad=$rows_cad['idcad'];
         $hidrometro=$rows_cad['numhidro'];
         $tipo_prop=$rows_cad['tipo'];
         $nome_prop=$rows_cad['proprietario'];
         $denomina=$rows_cad['denomina'];
         $logradouro=$rows_cad['ruas'];
         $numero=$rows_cad['numero'];
         $bairro=$rows_cad['bairros'];
         $secretaria=$rows_cad['secretarias'];
         $unidade=$rows_cad['unidade'];
         $referencia=$rows_cad['referencia'];
         $funcionamento=$rows_cad['funcionamento'];
         echo "<tr>";
         echo "<td><a href='alteracad.php?idcad=".$rows_cad['idcad']."'>".$rows_cad['idcad']."</td>";
         echo "<td>".$rows_cad['numhidro']."</td>";
         echo "<td>".$rows_cad['tipo']."</td>";
         echo "<td>".$rows_cad['proprietario']."</td>";
         echo "<td>".$rows_cad['denomina']."</td>";
         echo "<td>".$rows_cad['ruas']."</td>";
         echo "<td>".$rows_cad['numero']."</td>";
         echo "<td>".$rows_cad['bairros']."</td>";
         echo "<td>".$rows_cad['secretarias']."</td>";
         echo "<td>".$rows_cad['unidade']."</td>";
         echo "<td>".$rows_cad['referencia']."</td>";
         echo "<td>".$rows_cad['funcionamento']."</td>";
         echo "</tr>";
     }
         echo "</table>";

    }
    else 
    {
        unset ($idcad);
        unset ($ano);
    }

?>