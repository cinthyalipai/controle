<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

?>

<head>
    <meta charset="utf-8">
    <title>Informacoes sobre o Cadastro</title>
</head>

<body>
    <br><br><br>
<form name="info" method="POST" action="gravainfo.php">
    <table>
        <tr>
            <td>Número do Cadastro: </td>
            <td><input type="text" name="numcad" id="numcad" maxlength="8" required></td>
        </tr>
        <tr>
            <td>Data da Informação:</td>
            <td><input type="date" name="dia" id="dia"></td>
        </tr>
        <tr>
        <td>Descrição:</td>
        <td><textarea name="descricao" rows="5" cols="30" maxlength="500" required></textarea></td>
        </tr>
        <tr>
            <td><input type="submit" name="enviar" value="Gravar Informação"></td>
        </tr>
    </table>
</form>

