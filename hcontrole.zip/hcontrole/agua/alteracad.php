<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

$idcad = $_GET['idcad'];
$sqlcad = "SELECT * FROM imovel WHERE idcad='$idcad' ";   
$result = mysqli_query($conn, $sqlcad);   
$row = mysqli_fetch_array($result);
$tipoend = mysqli_query($conn, "SELECT idrua, ruas FROM ruas");
$tipobairro = mysqli_query($conn, "SELECT idbairro, bairros FROM bairros");
$tipoprop = mysqli_query($conn, "SELECT id, tipo FROM tipoprop");

?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
</head>
<body>
 
 <table border="2">
		<tr>
				<td align="center" colspan="8"><b> Informações Anteriores <b></td>
		</tr>
		<tr>
				<td><b>Cadastro</b></td>              
				<td><b>Hidrometro</b></td>  
				<td><b>Tipo Contrato</b></td> 
				<td><b>Proprietario Imovel</b></td>
				<td><b>Nome do Predio</b></td>
				<td><b>Endereco</b></td>
				<td><b>Numero</b></td>          
				<td><b>Bairro</b></td>
		</tr>

<?php


$sql_cad = "SELECT i.idcad, i.numhidro, t.tipo, i.proprietario, i.denomina, r.ruas, i.numero, b.bairros
            FROM imovel i, tipoprop t, ruas r, bairros b
            WHERE i.codtipoprop = t.id AND
            i.codlogradouro = r.idrua AND
            i.codbairro = b.idbairro AND
            i.idcad like '%$idcad%' 
			ORDER BY i.idcad";
$resultado_cad = mysqli_query($conn, $sql_cad);

while($rows_cad = mysqli_fetch_array($resultado_cad))
{
    $id_cad=$rows_cad['idcad'];
	$hidrometro=$rows_cad['numhidro'];
	$cod_prop=$rows_cad['tipo'];
	$nome_prop=$rows_cad['proprietario'];
	$denomina=$rows_cad['denomina'];
	$logradouro=$rows_cad['ruas'];
	$numero=$rows_cad['numero'];
	$bairro=$rows_cad['bairros'];
	echo "<tr>";
	echo "<td>".$rows_cad['idcad']."</td>";
	echo "<td>".$rows_cad['numhidro']."</td>";
	echo "<td>".$rows_cad['tipo']."</td>";
	echo "<td>".$rows_cad['proprietario']."</td>";
	echo "<td>".$rows_cad['denomina']."</td>";
	echo "<td>".$rows_cad['ruas']."</td>";
	echo "<td>".$rows_cad['numero']."</td>";
	echo "<td>".$rows_cad['bairros']."</td>";
	echo "</tr>";
}
	echo "</table>";

?>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

 <table border="1" cellpading="20" cellspacing="20">
 	<tr>
 		<td align="center"><b> Atualizacao de Cadastro Imobiliario </b>
 			<form name="atualizacao de imovel" method="post" action="alteracadsucess.php" >
 				<table cellpading="10" cellspacing="10">
 					<tr>
						 <td>Cadastro Semae:</td><td><?php echo $row['idcad']?></td>
												<td><input name="idcad" type="hidden" value="<?php echo $row['idcad']?>"></td>
 					</tr>
 					<tr>
						<td>Hidrometro:</td>
 						<td><input name="numhidro" type="text" size="20" maxlenght="50" value="<?php echo $row['numhidro']?>"></td>
 					</tr>
 					<tr>
						<td>Denominacao Predio:</td>
						<td><input name="denomina" type="text" size="100" maxlenght="30" value="<?php echo $row['denomina']?>"></td>
 					</tr>
 					<tr>
						<td>Endereco:</td>        
                        <td><select name="nome_rua"> 
                                <option>Selecione Endereço
                                </option>
                                <?php while($logradouro = mysqli_fetch_array($tipoend)) 
                                    { ?> 
                                    <option value="<?php echo $logradouro['idrua'] ?>"><?php echo $logradouro['ruas'] ?>
                                    </option> 
                                <?php } ?> 
                            </select></td> 
 					</tr>
 					<tr>
						<td>Numero:</td>
 						<td><input name="numero" type="text" size="10" maxlenght="30"  value="<?php echo $row['numero']?>" required></td>
 					</tr>
					<tr>
						<td>Bairro:</td>
 						<td><select name="nome_bairro"> 
                        <option>Selecione Bairro
                        </option>
                        <?php while($bairro = mysqli_fetch_array($tipobairro)) 
                        { ?> 
                            <option value="<?php echo $bairro['idbairro'] ?>"><?php echo $bairro['bairros'] ?>
                            </option>
                        <?php } ?> 
                    </select></td>
 					</tr>
 					<tr>
 					<td></td>
 					</tr>
					<tr>
						<td align="left"><input type="submit" name="Submit" value="Alterar">
 					</tr>
				 </table>
		</form>
 </tr>
 
	
 </table>
 </body>
</html>