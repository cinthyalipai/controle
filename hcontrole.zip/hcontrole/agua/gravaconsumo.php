<?php

include ('../connection/conexao.php');
include ('../semae/digitaconsumo.php');

$mes = $_POST['mes'];
$idcad = $_POST['numcad'];
$ref = $_POST['referencia'];
$consumoatual = $_POST['digconsumo'];
$valoratual = $_POST['digvalor'];
$consumoanterior = $_POST['consumoanterior'];
$temp = $consumoanterior;
$valoranterior = $_POST['valoranterior'];
$idconsumo = $_POST['idconsumo'];
$idvalor = $_POST['idvalor'];


// atualizando o valor digitado apenas para o cadastro correspondente

//consumo
for ($i = 0; $i < count($idconsumo);$i++)
{
    for ($j = 0; $j < count($consumoatual); $j++){

        if ($i == $j){
            $consumoatualizado = $consumoatual[$i]; 
            $idcaatualizar = $idconsumo[$j];
            $consumoanterior2 = $consumoanterior[$j];

            $gravacons = "UPDATE consumo c
                SET c.$mes='".$consumoatualizado."'
                WHERE c.idconsumo = '".$idcaatualizar."' ";
            $retornagravacons = mysqli_query($conn, $gravacons);
        }
    }
}

//valor
for ($k = 0; $k < count($idvalor);$k++)
{
    for ($l = 0; $l < count($valoratual); $l++){

        if ($k == $l){
            $valoratualizado = $valoratual[$k]; 
            $idvaatualizar = $idvalor[$l];
            $valoranterior2 = $valoranterior [$l];

            $gravaval = "UPDATE valores v
                SET v.$mes='".$valoratualizado."'
                WHERE v.idvalor = '".$idvaatualizar."' ";
            $retornagravaval = mysqli_query($conn, $gravaval);
        }
    }
}

if($retornagravacons && $retornagravaval){
    echo "Dados armazenados com sucesso";
}