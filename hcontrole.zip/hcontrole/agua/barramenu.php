<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link rel="stylesheet" type="text/css" href="../css/style.css" />
	</head>


<body leftmargin="0" topmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" bgcolor ="#F5F5F5">

	<?php include ('../restrito.php'); include('../encerrasessao.php'); ?>	
	
	<table width=100% border="0" align="center" cellpadding="10" cellspacing="10" bgcolor="#5F9EA0">
		<tr>
			<td align="center"><b>Quadro de Cadastros e Relatorios - Consumo</b></td>
		</tr>
		<table align="center" cellpadding="15" cellspacing="5" bgcolor="#F5F5F5">
			<tr>
				<td colspan="5">
					<nav>
						<ul class="menu">
								<li><a href="#">Cadastro</a>
							<ul>
								<li><a href="novocad.php">Inserir Novo Cadastro</a></li>
								<li><a href="atualizacad.php">Atualizar Dados do Imóvel</a></li>
								<li><a href="atualizasec.php">Atualizar Secretaria Responsável</a></li>
								<li><a href="cadinconsist.php">Cadastros Inconsistentes</a></li>
							</ul>
								</li>	
								<li><a href="#">Consulta</a>
							<ul>
								<li><a href="consultainfo.php">Informações do Cadastro</a></li>    
								<li><a href="pesquisapredios.php">Consultar Prédios Ativos por Ano</a></li>
								<li><a href="pesquisaendereco.php">Pesquisar Cadastro por Endereço</a></li> 
								<li><a href="consultasuplementacao.php">Consultar Necessidade de Suplementação no Ano</a></li> 
								<li><a href="consultapgto.php">Consultar Valores Pagos no Ano</a></li> 
								<li><a href="mediavalores.php">Consultar Consumo por Secretaria</a></li>
								<li><a href="consultaconsumo.php">Consultar Consumo por Cadastro</a></li>   
							</ul>
								</li>
								<li><a href="#">Digitação</a>
							<ul>
								<li><a href="digitaconsumo.php">Consumo Mensal</a></li>
								<li><a href="gravaempenho.php">Valores Empenhados</a></li>
								<li><a href="digitapgto.php">Valores Pagos</a></li>
								<li><a href="atualizainfo.php">Informações sobre o prédio</a></li>
								<li><a href="alterastatus.php">Mudança de Status dos Prédios</a></li> 
							</ul>
								</li>
								<li><a href="#">Relatórios</a>
							<ul>
								<li><a href="relatsuplementar.php">Relatório de Valores a Suplementar</a></li>
								<li><a href="relatcadativo.php">Prédios Ativos por Secretaria</a></li>
								<li><a href="relatimovelativo.php">Relatório de Imóveis Cadastrados Ativos</a></li>
							</ul>
								</li>
								<li><a href="#">Gráficos</a>
							<ul>
								<li><a href="grafcad.php">Gráfico de Consumo por Cadastro/Ano</a></li>
								<li><a href="#">Gráfico de Consumo por Secretaria/Ano</a></li>
							</ul>
								</li>
								<li><a href="../menu.php">Menu Principal</a></li>                
						</ul>
					</nav>
				</td>
			</tr>
		</table>
	</table>
</body>