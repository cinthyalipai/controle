<?php
    include ('../connection/conexao.php');
	include ('../semae/barramenu.php');


$tipoend = mysqli_query($conn, "SELECT idrua, ruas FROM ruas");
$tipobairro = mysqli_query($conn, "SELECT idbairro, bairros FROM bairros");
$tipoprop = mysqli_query($conn, "SELECT id, tipo FROM tipoprop");
$tiposec = mysqli_query($conn, "SELECT idsecretaria, secretarias FROM secretarias");
$tipound = mysqli_query($conn, "SELECT id, unidade FROM unidades");
$tiporef = mysqli_query($conn, "SELECT idref, referencia FROM referencia");

?>
<head>
  <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<br><br><br>
<body class="cadastro">
  <form action="tratacad.php" method="post" >
    <fieldset>
    <legend>Dados do Imóvel</legend>
        <label>Número Cadastro:</label>
        <input type="text" name="cadastro" id="cadastro" maxlength="25" /> 
        <label>Número Hidrômetro:</label>
        <input type="text" name="hidrometro" id="hidrometro" maxlength="25" /><br><br>
        <label>Tipo de Contrato:</label>
            <td> 
                <select name="tipo_loc"> 
                    <option>Selecione Tipo</option>   
                    <?php while($propriedade = mysqli_fetch_array($tipoprop)) 
                    { ?> 
                        <option value="<?php echo $propriedade['id'] ?>"><?php echo $propriedade['tipo'] ?></option> 
                    <?php } ?> 
                </select>
			</td>
        <label>Proprietário:</label>
        <input type="text" name="nome_prop" id="nome_prop" maxlength="100" />
        <label>Denominação do Prédio:</label>
        <input type="text" name="denomina" id="denomina" maxlength="100" /><br><br>
        <label>Endereço:</label>
            <td>
                <select name="nome_rua"> 
                    <option>Selecione Endereço</option>
                    <?php while($logradouro = mysqli_fetch_array($tipoend)) 
                    { ?> 
                        <option value="<?php echo $logradouro['idrua'] ?>"><?php echo $logradouro['ruas'] ?></option> 
                    <?php } ?> 
                </select>
            </td> 
        <label>Número Imóvel:</label>
        <input type="text" name="num_predio" id="num_predio" maxlength="25" />
        <label>Bairro:</label>
            <td>
                <select name="nome_bairro"> 
                    <option>Selecione Bairro</option>
                    <?php while($bairro = mysqli_fetch_array($tipobairro)) 
                    { ?> 
                        <option value="<?php echo $bairro['idbairro'] ?>"><?php echo $bairro['bairros'] ?></option>
                    <?php } ?> 
                </select>
            </td><br><br>
    </fieldset>
    <br><br><br><br>
    <fieldset>
    <legend>Dados da Secretaria</legend>
        <label>Secretaria:</label>
            <td>
                <select name="nome_sec"> 
                    <option>Selecione Secretaria</option>
                    <?php while($secretaria = mysqli_fetch_array($tiposec)) 
                    { ?> 
                        <option value="<?php echo $secretaria['idsecretaria'] ?>"><?php echo $secretaria['secretarias'] ?></option> 
                    <?php } ?> 
                </select>
            </td> 
        <label>Unidade:</label>
            <td>
                <select name="nome_und"> 
                    <option>Selecione Unidade</option>
                    <?php while($unidade = mysqli_fetch_array($tipound)) 
                    { ?> 
                        <option value="<?php echo $unidade['id'] ?>"><?php echo $unidade['unidade'] ?></option> 
                    <?php } ?> 
                </select>
            </td>
        <label>Referência:</label>
            <td>
                <select name="nome_ref"> 
                    <option>Selecione Referência</option>
                    <?php while($referencia = mysqli_fetch_array($tiporef)) 
                    { ?> 
                        <option value="<?php echo $referencia['idref'] ?>"><?php echo $referencia['referencia'] ?></option> 
                    <?php } ?> 
                </select>
            </td><br><br>
        <input type="checkbox" name="at2013"> 2013 
        <input type="checkbox" name="at2014"> 2014
        <input type="checkbox" name="at2015"> 2015 
        <input type="checkbox" name="at2016"> 2016 
        <input type="checkbox" name="at2017"> 2017
        <input type="checkbox" name="at2018"> 2018
        <input type="checkbox" name="at2019"> 2019
        <input type="checkbox" name="at2020"> 2020 
        <input type="checkbox" name="at2021"> 2021
        <input type="checkbox" name="at2022"> 2022
        <input type="checkbox" name="at2023"> 2023
        <input type="checkbox" name="at2024"> 2024 
        <input type="checkbox" name="at2025"> 2025
        <input type="checkbox" name="at2026"> 2026
        <input type="checkbox" name="at2027"> 2027
        <input type="checkbox" name="at2028"> 2028 
        <input type="checkbox" name="at2029"> 2029
        <input type="checkbox" name="at2030"> 2030 </td></tr><br><br>
    </fieldset>
    <br><br><br><br>
    <fieldset>
    <legend>Inserção no Sistema</legend>
        <br>
        <label>Data Inserção:</label>
        <?php $hoje=date('d/m/Y'); echo $hoje; ?><br><br>   <!--lembrar de cadastrar a data no BD  -->
        <?php echo "Usuário Responsável: ".$_SESSION['UsuarioNome'];?>
    </fieldset>
    <br><br>
    <input type="submit" value="Cadastrar" />
    </form>
</body>