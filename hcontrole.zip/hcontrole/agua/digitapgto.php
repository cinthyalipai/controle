<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');
$tiposec = mysqli_query($conn, "SELECT idsecretaria, secretarias FROM secretarias");
$tipound = mysqli_query($conn, "SELECT id, unidade FROM unidades");
?>

<head>
    <meta charset="utf-8">
    <title>Digitação de Valores Pagos</title>
</head>

<body>
    <br><br><br>
        <form name="status" method="POST" action="">
            <table >
                <tr>
                    <td>Operação Desejada:</td>
                    <td>
                        <select name="selecao">
                            <option value="1">Incluir Unidade Orçamentária</option>
                            <option value="2">Incluir Pagamento</option>
                        </select>
                    <td colspan='2' align='right'><input type="submit" name="enviar" value="Selecionar"></td>
                </tr>
            </table>
        </form>
    <br><br><br>
<?php

if (isset($_POST['selecao']))
    {
    
        $altera = $_POST['selecao'];

        if ($altera == 1)
        {
        ?>
            <br><br><br><br><br>
            <form name ="novaunidade" action = 'cadastrapgto.php' method='POST'>
                <table>
                    <th colspan='2'>Unidades Orçamentárias</th>
                    <tr>
                        <td>Secretaria:</td>
                        <td>
                            <select name="nome_sec">
                                <option>Selecione Secretaria</option>
                                <?php while($secretaria = mysqli_fetch_array($tiposec))
                                { ?>
                                    <option value="<?php echo $secretaria['idsecretaria'] ?>"><?php echo $secretaria['secretarias'] ?></option>
                                <?php } ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Unidade:</td>
                        <td>
                        <select name="nome_und"> 
                            <option>Selecione Unidade</option>
                            <?php while($unidade = mysqli_fetch_array($tipound)) 
                            { ?> 
                                <option value="<?php echo $unidade['id'] ?>"><?php echo $unidade['unidade'] ?></option> 
                            <?php } ?> 
                        </select>
                    </td> 
                    </tr>
                    <tr><td></td><td></td></tr>
                    <tr>
                        <input type="hidden" name="alteracao" id="alteracao" value="<?php echo $altera?>"/>
                        <td colspan='2' align='right'>
                            <input type='submit' name='enviar' id='enviar' value='Gravar'>
                        </td>
                    </tr>
                </table>
            </form>

        <?php
        }
        elseif ($altera == 2)
        {
        ?>
            <form name="cadastro" method="POST" action="cadastrapgto.php">
                <table>
                    <tr>
                        <td>Mes Vencimento:</td>
                        <td>
                            <select name="mes">
                                <option value="1">Janeiro</option>
                                <option value="2">Fevereiro</option>
                                <option value="3">Março</option>
                                <option value="4">Abril</option>
                                <option value="5">Maio</option>
                                <option value="6">Junho</option>
                                <option value="7">Julho</option>
                                <option value="8">Agosto</option>
                                <option value="9">Setembro</option>
                                <option value="10">Outubro</option>
                                <option value="11">Novembro</option>
                                <option value="12">Dezembro</option>
                                </select>
                        </td>
                        <td></td><td></td><td></td><td></td>
                        <input type="hidden" name="alteracao" id="alteracao" value="<?php echo $altera?>"/>
                        <td align="right" colspan="2"><input type="submit" value="Selecionar"></td>
                    </tr>
                </table>
            </form>
        <?php    
        }
    }
?>


</body>
    

