<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');
$tiposec = mysqli_query($conn, "SELECT idsecretaria, secretarias FROM secretarias");
?>
<head>
    <meta charset="utf-8">
    <title>Pesquisa Por Secretaria</title>
</head>
<body>
    <br>
    <form name="pesquisa" method="POST" action="mediavalores.php">
        <table>
            <th colspan='2'>Consulta de Consumo por Secretaria e Ano</th>
            <tr>
                <td>Secretaria:</td>
                <td>
                    <select name="nome_sec">
                        <option>Selecione Secretaria</option>
                        <?php while($secretaria = mysqli_fetch_array($tiposec))
                        { ?>
                            <option value="<?php echo $secretaria['idsecretaria'] ?>"><?php echo $secretaria['secretarias'] ?></option>
                        <?php } ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Ano:</td>
                <td><input type="text" name="ano" id="ano" maxlength="4" required/></td>
            </tr>
            <tr>
                <td align="right" colspan="2"><input type="submit" value="Pesquisar"></td>
            </tr>
        </table>
    </form>

<?php


if (isset($_POST['ano']) and $_POST['nome_sec']=="Selecione Secretaria")
{
    echo "<br><br><br><h3 align='center'> Favor Selecionar Secretaria </h3>";
}

elseif (isset($_POST['ano']) and $_POST['nome_sec']<>"Selecione Secretaria")
{
    $ano = $_POST['ano'];
    $secretaria = $_POST['nome_sec'];

    echo "<br><br><br>";
    echo "<table border='2'>";
    echo "<th colspan='30'>Consumo Mensal</th>";
    echo "<tr>";
    echo "<td><b>Cadastro</b></td>";
    echo "<td><b>Total Meses</b></td>";
    echo "<td><b>Jan m³</b></td>";
    echo "<td><b>Jan R$</b></td>";
    echo "<td><b>Fev m³</b></td>";
    echo "<td><b>Fev R$</b></td>";
    echo "<td><b>Mar m³</b></td>";
    echo "<td><b>Mar R$</b></td>";
    echo "<td><b>Abr m³</b></td>";
    echo "<td><b>Abr R$</b></td>";
    echo "<td><b>Mai m³</b></td>";
    echo "<td><b>Mai R$</b></td>";
    echo "<td><b>Jun m³</b></td>";
    echo "<td><b>Jun R$</b></td>";
    echo "<td><b>Jul m³</b></td>";
    echo "<td><b>Jul R$</b></td>";
    echo "<td><b>Ago m³</b></td>";
    echo "<td><b>Ago R$</b></td>";
    echo "<td><b>Set m³</b></td>";
    echo "<td><b>Set R$</b></td>";
    echo "<td><b>Out m³</b></td>";
    echo "<td><b>Out R$</b></td>";
    echo "<td><b>Nov m³</b></td>";
    echo "<td><b>Nov R$</b></td>";
    echo "<td><b>Dez m³</b></td>";
    echo "<td><b>Dez R$</b></td>";
    echo "<td><b>Soma m³</b></td>";
    echo "<td><b>Média m³</b></td>";
    echo "<td><b>Soma R$</b></td>";
    echo "<td><b>Média R$</b></td>";
    echo "</tr>";

$sql_consumo = "SELECT p.numcad,
                    c.1 as cons_jan, v.1 as val_jan, c.2 as cons_fev, v.2 as val_fev,
                    c.3 as cons_mar, v.3 as val_mar, c.4 as cons_abr, v.4 as val_abr,
                    c.5 as cons_mai, v.5 as val_mai, c.6 as cons_jun, v.6 as val_jun,
                    c.7 as cons_jul, v.7 as val_jul, c.8 as cons_ago, v.8 as val_ago,
                    c.9 as cons_set, v.9 as val_set, c.10 as cons_out, v.10 as val_out,
                    c.11 as cons_nov, v.11 as val_nov, c.12 as cons_dez, v.12 as val_dez
                    FROM consumo c, valores v, pasta p, secretarias s
                    WHERE p.idpasta = c.codpasta AND
                        p.idpasta = v.codpasta AND
                        c.idconsumo = v.idvalor AND
                        p.codsec = s.idsecretaria AND
                        s.idsecretaria = $secretaria AND
                        c.ano = $ano
                    ORDER BY c.ano ASC, p.numcad ASC";
$resultado_sqlconsumo = mysqli_query($conn, $sql_consumo);
$rows_sqlconsumo = mysqli_fetch_array($resultado_sqlconsumo);
    
do
{

$filtroarray = array_filter($rows_sqlconsumo); //limpa valores nulos e zeros
$zeros = array("0.00"); //exclui valores 0.00 da tabela valores
$arraylimpo = array_diff($filtroarray, $zeros); //calcula a diferenca entre os arrays e me retorna o array totalmente limpo de zerps
array_count_values($arraylimpo); //conta numero de meses dentro do array
$contafiltro = count($arraylimpo); //checa a contagem do array
$intfiltro = (int)$contafiltro; //transforma o valor encontrado em inteiro
$metadefiltro = intval(($intfiltro-1)/4); //faz a operacao para obter a média

$contajan=$rows_sqlconsumo['cons_jan'];
$contafev=$rows_sqlconsumo['cons_fev'];
$contamar=$rows_sqlconsumo['cons_mar'];
$contaabr=$rows_sqlconsumo['cons_abr'];
$contamai=$rows_sqlconsumo['cons_mai'];
$contajun=$rows_sqlconsumo['cons_jun'];
$contajul=$rows_sqlconsumo['cons_jul'];
$contaago=$rows_sqlconsumo['cons_ago'];
$contaset=$rows_sqlconsumo['cons_set'];
$contaout=$rows_sqlconsumo['cons_out'];
$contanov=$rows_sqlconsumo['cons_nov'];
$contadez=$rows_sqlconsumo['cons_dez'];
$valorjan=$rows_sqlconsumo['val_jan'];
$valorfev=$rows_sqlconsumo['val_fev'];
$valormar=$rows_sqlconsumo['val_mar'];
$valorabr=$rows_sqlconsumo['val_abr'];
$valormai=$rows_sqlconsumo['val_mai'];
$valorjun=$rows_sqlconsumo['val_jun'];
$valorjul=$rows_sqlconsumo['val_jul'];
$valorago=$rows_sqlconsumo['val_ago'];
$valorset=$rows_sqlconsumo['val_set'];
$valorout=$rows_sqlconsumo['val_out'];
$valornov=$rows_sqlconsumo['val_nov'];
$valordez=$rows_sqlconsumo['val_dez'];


//soma os valores dos itens das linhas de consumo
$consumo = (float)$contajan + (float)$contafev + (float)$contamar + (float)$contaabr +
(float)$contamai + (float)$contajun + (float)$contajul + (float)$contaago +
(float)$contaset + (float)$contaout + (float)$contanov + (float)$contadez;

//soma os valores dos itens das linhas de valor
$valor = (float)$valorjan + (float)$valorfev + (float)$valormar + (float)$valorabr +
(float)$valormai + (float)$valorjun + (float)$valorjul + (float)$valorago +
(float)$valorset + (float)$valorout + (float)$valornov + (float)$valordez;


echo "<tr>";
    echo "<td>".$rows_sqlconsumo['numcad']."</td>";
    echo "<td align='center'>".$metadefiltro."</td>";
    echo "<td>".$rows_sqlconsumo['cons_jan']."</td>";
    echo "<td>".number_format($rows_sqlconsumo['val_jan'],2,',','')."</td>";
    echo "<td>".$rows_sqlconsumo['cons_fev']."</td>";
    echo "<td>".number_format($rows_sqlconsumo['val_fev'],2,',','')."</td>";
    echo "<td>".$rows_sqlconsumo['cons_mar']."</td>";
    echo "<td>".number_format($rows_sqlconsumo['val_mar'],2,',','')."</td>";
    echo "<td>".$rows_sqlconsumo['cons_abr']."</td>";
    echo "<td>".number_format($rows_sqlconsumo['val_abr'],2,',','')."</td>";
    echo "<td>".$rows_sqlconsumo['cons_mai']."</td>";
    echo "<td>".number_format($rows_sqlconsumo['val_mai'],2,',','')."</td>";
    echo "<td>".$rows_sqlconsumo['cons_jun']."</td>";
    echo "<td>".number_format($rows_sqlconsumo['val_jun'],2,',','')."</td>";
    echo "<td>".$rows_sqlconsumo['cons_jul']."</td>";
    echo "<td>".number_format($rows_sqlconsumo['val_jul'],2,',','')."</td>";
    echo "<td>".$rows_sqlconsumo['cons_ago']."</td>";
    echo "<td>".number_format($rows_sqlconsumo['val_ago'],2,',','')."</td>";
    echo "<td>".$rows_sqlconsumo['cons_set']."</td>";
    echo "<td>".number_format($rows_sqlconsumo['val_set'],2,',','')."</td>";
    echo "<td>".$rows_sqlconsumo['cons_out']."</td>";
    echo "<td>".number_format($rows_sqlconsumo['val_out'],2,',','')."</td>";
    echo "<td>".$rows_sqlconsumo['cons_nov']."</td>";
    echo "<td>".number_format($rows_sqlconsumo['val_nov'],2,',','')."</td>";
    echo "<td>".$rows_sqlconsumo['cons_dez']."</td>";
    echo "<td>".number_format($rows_sqlconsumo['val_dez'],2,',','')."</td>";



    echo "<td>".$consumo."</td>";
    if ($metadefiltro == 0)
        {
            $somazeroconsumo = 0;
            echo "<td>".$somazeroconsumo."</td>";
        }
    else
        {
            echo "<td>".number_format($consumo/$metadefiltro,2,',','')."</td>";
        }

    echo "<td>".number_format($valor,2,',','')."</td>";
    if ($metadefiltro == 0)
        {
            $somazerovalor = 0;
            echo "<td>".$somazerovalor."</td>";
        }
    else
        {
            echo "<td>".number_format($valor/$metadefiltro,2,',','')."</td>";
        }
    
} 

while($rows_sqlconsumo = mysqli_fetch_array($resultado_sqlconsumo));

echo "</table>";

}


?>

</body>