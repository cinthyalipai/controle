<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

$tiposec = mysqli_query($conn, "SELECT idsecretaria, secretarias FROM secretarias");
$tipound = mysqli_query($conn, "SELECT id, unidade FROM unidades");
?>

<head>
    <meta charset="utf-8">
    <title>Digitação de Valores Empenhados</title>
</head>

<body>
    <br><br><br>
    <form name="empenho" method="POST" action="gravaempenho.php">
    <table>
        <tr>
            <td>Secretaria: </td>
            <td>
                    <select name="nome_sec"> 
                        <option>Selecione Secretaria</option>
                        <?php while($secretaria = mysqli_fetch_array($tiposec)) 
                        { ?> 
                            <option value="<?php echo $secretaria['idsecretaria'] ?>"><?php echo $secretaria['secretarias'] ?></option> 
                        <?php } ?> 
                    </select>
            </td>
        </tr>
        <tr>
            <td>Unidade:</td>
            <td>
                <select name="nome_und"> 
                    <option>Selecione Unidade</option>
                    <?php while($unidade = mysqli_fetch_array($tipound)) 
                    { ?> 
                        <option value="<?php echo $unidade['id'] ?>"><?php echo $unidade['unidade'] ?></option> 
                    <?php } ?> 
                </select>
            </td> 
        </tr>
        <tr>
        <td>Ano:</td>
        <td><input type="number" name="ano" id="ano" minlenght="4" maxlength="4" required></td>
        </tr>
        <tr>
        <td>Tipo da Operação: </td>
        <td>
            <select name="opcao">
                <option value=1>Novo Cadastro</option>
                <option value=2>Atualizar Dados</option>
            </select>
        </td>
        </table>
    <br>
    <input type="submit" name="enviar" value="Enviar">
</form>

<?php

    if (isset($_POST['ano']) and $_POST['nome_sec']<>"Selecione Secretaria" and $_POST['nome_und']<>"Selecione Unidade")
    {
        $secretaria=$_POST['nome_sec'];
        $unidade = $_POST['nome_und'];
        $ano = $_POST['ano'];
        $selecao = $_POST['opcao'];

        if($selecao == 1) // insere novos dados de empenho
        {
        ?>
        <br><br><br>
        <form name="novo_empenho" method="POST" action="processempenho.php">
            <tr>
                <td>Dotação:</td>
                <td><input type="text" name="dotacao" id="dotacao" maxlength="41" placeholder="00.000.00.000.0000.0.000.000000.00.000000"required ></td>
            </tr>
            <tr>
                <td>Ficha Empenho:</td>
                <td><input type="number" name="ficha" id="ficha" maxlength="4" placeholder = "0000" required></td>
            </tr>
            <tr>
                <td>Número Empenho Inicial:</td>
                <td><input type="number" name="empinicial" id="empinicial" maxlength="5" placeholder="00000" required></td>
                <td>Valor Empenho Inicial:</td>
                <td><input type="number" name="valorinicial" id="valorinicial" maxlength="11" required></td>
            <tr>
            <tr>
                <td></td>
                <td><input type="submit" name="grava_empenho" id="grava_empenho" value="Gravar Informações"></td>
            </tr>
            <td><input type="hidden" name="secretaria" value="<?php echo $secretaria ?>"></td>
            <td><input type="hidden" name="unidade" value="<?php echo $unidade ?>"></td>
            <td><input type="hidden" name="ano" value="<?php echo $ano ?>"></td>
            <td><input type="hidden" name="selecao" value="<?php echo $selecao ?>"></td>
        </form>
        <?php
        }
        elseif($selecao == 2) //mostrando a consulta realizada para o usuario
        {
            $consultaempenho = "SELECT s.secretarias, 
                                        u.unidade, 
                                        e.ano, 
                                        e.dotacao, 
                                        e.ficha, 
                                        e.num_empenho, 
                                        e.valor_inicial
                                FROM empenho e, secretarias s, unidades u
                                WHERE e.codsecretaria = s.idsecretaria
                                and e.codund = u.id
                                and e.codsecretaria='".$secretaria."' 
                                and e.codund='".$unidade."' 
                                and e.ano='".$ano."' ";
            $resultconsulta = mysqli_query($conn, $consultaempenho);
            $rows_consulta = mysqli_fetch_array($resultconsulta);

            echo "<br><br><br>";
            echo "<table border='1'>";
            echo "<tr>";
                echo "<td> Secretaria Pesquisada: </td>";
                echo "<td> Unidade Pesquisada: </td>";
                echo "<td> Ano Pesquisado: </td>";
                echo "<td> Dotação: </td>";
                echo "<td> Ficha: </td>";
                echo "<td> Empenho Inicial: </td>";
                echo "<td> Valor Inicial: </td>";
            echo "</tr>";
            echo "<tr>";
                echo "<td>".$rows_consulta['secretarias']."</td>";
                echo "<td>".$rows_consulta['unidade']."</td>";
                echo "<td>".$rows_consulta['ano']."</td>";
                echo "<td>".$rows_consulta['dotacao']."</td>";
                echo "<td>".$rows_consulta['ficha']."</td>";
                echo "<td>".$rows_consulta['num_empenho']."</td>";
                echo "<td>".number_format($rows_consulta['valor_inicial'],2,',','.')."</td>";
            echo "</tr>";
            echo "</table>";


        ?>
        <br><br>
        <form name="empenho" method="POST" action="processempenho.php">
            <table>
                <tr>
                    <td>Número Empenho Suplementar 1:</td>
                    <td><input type="number" name="empsup1" id="empsup1" maxlength="5" placeholder="00000"></td>
                    <td>Valor Empenho Suplementar 1:</td>
                    <td><input type="number" name="valsup1" id="valsup1" maxlength="11" step=".01"></td>
                    <td>Valor Anulação 1:</td>
                    <td><input type="number" name="anula1" id="anula1" maxlength="11" step=".01"></td>
                </tr>
                <tr>
                    <td>Número Empenho Suplementar 2:</td>
                    <td><input type="number" name="empsup2" id="empsup2" maxlength="5" placeholder="00000"></td>
                    <td>Valor Empenho Suplementar 2:</td>
                    <td><input type="number" name="valsup2" id="valsup2" maxlength="11" step=".01"></td>
                    <td>Valor Anulação 2:</td>
                    <td><input type="number" name="anula2" id="anula2" maxlength="11" step=".01"></td>
                </tr>
                <tr>
                    <td>Número Empenho Suplementar 3:</td>
                    <td><input type="number" name="empsup3" id="empsup3" maxlength="5" placeholder="00000"></td>
                    <td>Valor Empenho Suplementar 3:</td>
                    <td><input type="number" name="valsup3" id="valsup3" maxlength="11" step=".01"></td>
                    <td>Valor Anulação 3:</td>
                    <td><input type="number" name="anula3" id="anula3" maxlength="11" step=".01"></td>
                </tr>
                <tr>
                    <td>Número Empenho Suplementar 4:</td>
                    <td><input type="number" name="empsup4" id="empsup4" maxlength="5" placeholder="00000"></td>
                    <td>Valor Empenho Suplementar 4:</td>
                    <td><input type="number" name="valsup4" id="valsup4" maxlength="11" step=".01"></td>
                    <td>Valor Anulação 4:</td>
                    <td><input type="number" name="anula4" id="anula4" maxlength="11" step=".01"></td>
                </tr>
                <tr>
                    <td>Número Empenho Suplementar 5:</td>
                    <td><input type="number" name="empsup5" id="empsup5" maxlength="5" placeholder="00000"></td>
                    <td>Valor Empenho Suplementar 5:</td>
                    <td><input type="number" name="valsup5" id="valsup5" maxlength="11" step=".01"></td>
                    <td>Valor Anulação 5:</td>
                    <td><input type="number" name="anula5" id="anula5" maxlength="11" step=".01"></td>
                </tr>
                <tr>
                    <td>Número Empenho Suplementar 6:</td>
                    <td><input type="number" name="empsup6" id="empsup6" maxlength="5" placeholder="00000"></td>
                    <td>Valor Empenho Suplementar 6:</td>
                    <td><input type="number" name="valsup6" id="valsup6" maxlength="11" step=".01"></td>
                    <td>Valor Anulação 6:</td>
                    <td><input type="number" name="anula6" id="anula6" maxlength="11" step=".01"></td>
                </tr>
                    <td><input type="hidden" name="secretaria" value="<?php echo $secretaria ?>"></td>
                    <td><input type="hidden" name="unidade" value="<?php echo $unidade ?>"></td>
                    <td><input type="hidden" name="ano" value="<?php echo $ano ?>"></td>
                    <td><input type="hidden" name="selecao" value="<?php echo $selecao ?>"></td>
            </table>
                <input type="submit" name="enviar" value="Gravar Informação">
        </form>
        <?php
        }
    }
    elseif (isset($_POST['ano']) and $_POST['nome_sec'] == "Selecione Secretaria" and $_POST['nome_und'] <> "Selecione Unidade")
        echo "<br><br>Favor preencher todos os dados relativos à Unidade Orçamentária";

    elseif (isset($_POST['ano']) and $_POST['nome_sec'] <> "Selecione Secretaria" and $_POST['nome_und'] == "Selecione Unidade")
        echo "<br><br>Favor preencher todos os dados relativos à Unidade Orçamentária";

?>
