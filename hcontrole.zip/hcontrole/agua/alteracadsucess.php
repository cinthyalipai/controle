<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

$idcad=$_POST['idcad'];
$hidrometro=$_POST['numhidro'];
$denomina=$_POST['denomina'];
$idrua=$_POST['nome_rua'];
$numero=$_POST['numero'];
$idbairro=$_POST['nome_bairro'];

$sql_sucess_alt="UPDATE imovel SET
                        numhidro='".$hidrometro."',
                        denomina='".$denomina."',
                        codlogradouro='".$idrua."',
                        numero='".$numero."',
                        codbairro='".$idbairro."'
                        WHERE idcad='".$idcad."' ";

$result_sucess_alt = mysqli_query($conn, $sql_sucess_alt);


if($result_sucess_alt) {

echo "<body>";

echo"<table border='1'>";
echo"<tr>";
    echo"<td><b>Cadastro</b></td>";              
    echo"<td><b>Hidrometro</b></td>"; 
    echo"<td><b>Tipo Contrato</b></td>";             
    echo"<td><b>Proprietario Imovel</b></td>";
    echo"<td><b>Nome do Predio</b></td>";
    echo"<td><b>Endereco</b></td>";
    echo"<td><b>Numero</b></td>";          
    echo"<td><b>Bairro</b></td>";
echo"</tr>";

$sql_cad = "SELECT i.idcad, i.numhidro, t.tipo, i.proprietario, i.denomina, r.ruas, i.numero, b.bairros
            FROM imovel i, tipoprop t, ruas r, bairros b
            WHERE i.codtipoprop = t.id AND
            i.codlogradouro = r.idrua AND
            i.codbairro = b.idbairro AND
            i.idcad like '$idcad' ";
$resultado_cad = mysqli_query($conn, $sql_cad);

while($rows_cad = mysqli_fetch_array($resultado_cad))
{
    $id_cad=$rows_cad['idcad'];
	$hidrometro=$rows_cad['numhidro'];
	$cod_prop=$rows_cad['tipo'];
	$nome_prop=$rows_cad['proprietario'];
	$denomina=$rows_cad['denomina'];
	$logradouro=$rows_cad['ruas'];
	$numero=$rows_cad['numero'];
	$bairro=$rows_cad['bairros'];
	echo "<tr>";
	echo "<td>".$rows_cad['idcad']."</td>";
	echo "<td>".$rows_cad['numhidro']."</td>";
	echo "<td>".$rows_cad['tipo']."</td>";
	echo "<td>".$rows_cad['proprietario']."</td>";
	echo "<td>".$rows_cad['denomina']."</td>";
	echo "<td>".$rows_cad['ruas']."</td>";
	echo "<td>".$rows_cad['numero']."</td>";
	echo "<td>".$rows_cad['bairros']."</td>";
	echo "</tr>";
}
	echo "</table>";

}    

else

    echo "A alteração no cadastro ".$idcad." não pôde ser realizada!";

?>