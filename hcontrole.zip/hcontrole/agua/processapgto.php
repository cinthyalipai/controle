<?php

include ('../connection/conexao.php');
include ('../semae/cadastrapgto.php');

$mes = $_POST['mes'];
$ano = $_POST['ano'];
$secretaria = $_POST['secretarias'];
$unidade = $_POST['unidade'];
$valoranterior = $_POST['valoranterior']; 
$temp = $valoranterior;
$idpgto = $_POST['idpgto'];
$valoratual = $_POST['novovalor'];

// atualizando o valor digitado apenas para o cadastro correspondente
for ($k = 0; $k < count($idpgto);$k++)
{
    for ($l = 0; $l < count($valoratual); $l++){

        if ($k == $l){
            $valoratualizado = floatval($valoratual[$k]); 
            $idvaatualizar = $idpgto[$l];
            $valoranterior2 = $valoranterior [$l];

            $gravaval = "UPDATE pagamento p
                SET p.$mes='".$valoratualizado."'
                WHERE p.idpgto = '".$idvaatualizar."' ";
            $retornagravaval = mysqli_query($conn, $gravaval);
        }
    }
}
    if($retornagravaval)
    {
        echo "<br><br>";
        echo "<b>Os valores foram atualizados para o mês ".$mes." do ano ".$ano."</b>";
    }


