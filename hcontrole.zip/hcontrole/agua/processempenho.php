<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

?>

<?php

if(isset($_POST['dotacao']) and isset($_POST['ficha']) and isset($_POST['empinicial']) and isset($_POST['valorinicial']) and $_POST['selecao']==1)
{
    $novasecretaria = $_POST['secretaria'];
    $novaunidade = $_POST['unidade'];
    $incluiano = $_POST['ano'];
    $dotacao = $_POST['dotacao'];
    $ficha = $_POST['ficha'];
    $empenho = $_POST['empinicial'];
    $valor = $_POST['valorinicial'];

    $cadastraempenho = "INSERT INTO empenho (codsecretaria, codund, ano, dotacao, ficha, num_empenho, valor_inicial) 
                        VALUES ('".$novasecretaria."','".$novaunidade."','".$incluiano."', '".$dotacao."','".$ficha."','".$empenho."','".$valor."' )";
    $resultcadastro = mysqli_query($conn, $cadastraempenho);

    if (!$resultcadastro) echo "Dados não foram gravados"; else echo "Dados gravados com sucesso";
}

elseif($_POST['selecao']==2)
{
    $novasecretaria = $_POST['secretaria'];
    $novaunidade = $_POST['unidade'];
    $incluiano = $_POST['ano'];
    
    if (empty($_POST['empsup1'])) $empsuplementar1 = "00000"; else  $empsuplementar1 = $_POST['empsup1'];
    if (empty($_POST['valsup1'])) $valsuplementar1 = "0.00"; else  $valsuplementar1 = $_POST['valsup1'];
    if (empty($_POST['anula1'])) $anula1 = "0.00"; else  $anula1 = $_POST['anula1'];
    if (empty($_POST['empsup2'])) $empsuplementar2 = "00000"; else  $empsuplementar2 = $_POST['empsup2'];
    if (empty($_POST['valsup2'])) $valsuplementar2 = "0.00"; else  $valsuplementar2 = $_POST['valsup2'];
    if (empty($_POST['anula2'])) $anula2 = "0.00"; else  $anula2 = $_POST['anula2'];
    if (empty($_POST['empsup3'])) $empsuplementar3 = "00000"; else  $empsuplementar3 = $_POST['empsup3'];
    if (empty($_POST['valsup3'])) $valsuplementar3 = "0.00"; else  $valsuplementar3 = $_POST['valsup3'];
    if (empty($_POST['anula3'])) $anula3 = "0.00"; else  $anula3 = $_POST['anula3'];
    if (empty($_POST['empsup4'])) $empsuplementar4 = "00000"; else  $empsuplementar4 = $_POST['empsup4'];
    if (empty($_POST['valsup4'])) $valsuplementar4 = "0.00"; else  $valsuplementar4 = $_POST['valsup4'];
    if (empty($_POST['anula4'])) $anula4 = "0.00"; else  $anula4 = $_POST['anula4'];
    if (empty($_POST['empsup5'])) $empsuplementar5 = "00000"; else  $empsuplementar5 = $_POST['empsup5'];
    if (empty($_POST['valsup5'])) $valsuplementar5 = "0.00"; else  $valsuplementar5 = $_POST['valsup5'];
    if (empty($_POST['anula5'])) $anula5 = "0.00"; else  $anula5 = $_POST['anula5'];
    if (empty($_POST['empsup6'])) $empsuplementar6 = "00000"; else  $empsuplementar6 = $_POST['empsup6'];
    if (empty($_POST['valsup6'])) $valsuplementar6 = "0.00"; else  $valsuplementar6 = $_POST['valsup6'];
    if (empty($_POST['anula6'])) $anula6 = "0.00"; else  $anula6 = $_POST['anula6'];

    $atualizaempenho = "UPDATE empenho 
                        SET emp_suplementar1 = '".$empsuplementar1."',
                            valor_suplementar1 = '".$valsuplementar1."',
                            valor_anulacao1 = '".$anula1."',
                            emp_suplementar2 = '".$empsuplementar2."',
                            valor_suplementar2 = '".$valsuplementar2."',
                            valor_anulacao2 = '".$anula2."',
                            emp_suplementar3 = '".$empsuplementar3."',
                            valor_suplementar3 = '".$valsuplementar3."',
                            valor_anulacao3 = '".$anula3."',
                            emp_suplementar4 = '".$empsuplementar4."',
                            valor_suplementar4 = '".$valsuplementar4."',
                            valor_anulacao4 = '".$anula4."',
                            emp_suplementar5 = '".$empsuplementar5."',
                            valor_suplementar5 = '".$valsuplementar5."',
                            valor_anulacao5 = '".$anula5."',
                            emp_suplementar6 = '".$empsuplementar6."',
                            valor_suplementar6 = '".$valsuplementar6."',
                            valor_anulacao6 = '".$anula6."'
                        WHERE codsecretaria='".$novasecretaria."' AND codund='".$novaunidade."' AND ano='".$incluiano."' ";
    $resultatualizaempenho = mysqli_query($conn, $atualizaempenho);
    if (!$resultatualizaempenho) echo "Dados não foram gravados"; else echo "Dados gravados com sucesso";
}
?>
