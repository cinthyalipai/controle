<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');
?>

<head>
    <meta charset="utf-8">
    <title>Cadastros Inconsistentes</title>
</head>
<body>
<?php
    
$sql = "SELECT i.idcad, i.numhidro, t.tipo, i.proprietario, i.denomina
        FROM imovel i, tipoprop t
        WHERE i.codtipoprop = t.id AND
            (i.codlogradouro = 0 or i.codbairro = 0)
        ORDER BY i.idcad ASC";
$resultsql= mysqli_query($conn, $sql);
$rows_sql = mysqli_fetch_array($resultsql);
$num_rows = mysqli_num_rows($resultsql);
error_reporting(0);
if($rows_sql >0)
{   
    echo "<br>";
    echo"<table border='1'>";
    echo "<th colspan='6'>Cadastros a Verificar - ".$num_rows."</th>";
    echo"<tr>";
        echo"<td><b>Cadastro</b></td>";              
        echo"<td><b>Hidrometro</b></td>"; 
        echo"<td><b>Tipo Contrato</b></td>";             
        echo"<td><b>Proprietario Imovel</b></td>";
        echo"<td><b>Nome do Predio</b></td>";
    echo"</tr>";
    $idcad=$rows_sql['idcad'];
    $hidrometro=$rows_sql['numhidro'];
    $tipo_prop=$rows_sql['tipo'];
    $nome_prop=$rows_sql['proprietario'];
    $denomina=$rows_sql['denomina'];
        do
        {   
            echo "<tr>";
            echo "<td><a href='alteracad.php?idcad=".$rows_sql['idcad']."'>".$rows_sql['idcad']."</td>";
            echo "<td>".$rows_sql['numhidro']."</td>";
            echo "<td>".$rows_sql['tipo']."</td>";
            echo "<td>".$rows_sql['proprietario']."</td>";
            echo "<td>".$rows_sql['denomina']."</td>";
            echo "</tr>";
        } while($rows_sql = mysqli_fetch_array($resultsql));
} else 
{
    echo "<br>";echo "<br>";echo "<br>";
    echo "<h2 align='center'>Não há cadastros inconsistentes</h2>";
}
?>

</body>