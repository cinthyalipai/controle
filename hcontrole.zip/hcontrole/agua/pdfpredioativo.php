<?php
include ('../connection/conexao.php');
?>

<?php 
error_reporting(0);

require ('../../../fpdf/fpdf.php');

$ano = $_POST['ano'];

$consulta = "SELECT s.secretarias, u.unidade, p.numcad, r.referencia
                FROM imovel i, pasta p, secretarias s, unidades u, referencia r
                WHERE p.numcad = i.idcad AND
                    r.idref = p.codref AND
                    s.idsecretaria = p.codsec AND
                    u.id = p.codund AND
                    p.at$ano like 'Ativo'
                ORDER BY s.secretarias ASC, u.unidade ASC, r.referencia DESC, p.numcad ASC";
$result = mysqli_query($conn, $consulta);

$pdf = new FPDF('P','mm','A4'); //instala classe para gerar documento
$pdf -> AddPage(); //adiciona pagina ao documento
$pdf->SetXY(10, 10);
$pdf-> SetFont ('Arial', 'B', 12); // cria o título da página
$pdf-> Cell (150,5, utf8_decode('Prédios Ativos por Secretaria em '.$ano), 0,0, 'C');
$pdf-> Ln (10);
$pdf-> SetFillColor (232,232,232);
$pdf-> SetFont ('Arial', 'B', 8);
//células dos títulos das colunas
$pdf-> Cell (35,10, utf8_decode('Secretaria'), 1,0, 'C', 1);
$pdf-> Cell (30,10, utf8_decode('Unidade'), 1,0, 'C', 1);
$pdf-> Cell (30,10, utf8_decode('Referência'), 1,0, 'C', 1);
$pdf-> Cell (15,10, utf8_decode('Cadastro'), 1,0, 'C', 1);
$pdf-> Cell (60,10, utf8_decode('Obs.:'), 1,0, 'C', 1);
$pdf-> Ln (10);

//comeca a listar a consulta
while($rowsresult=mysqli_fetch_array($result))
{
    $psecretaria = $rowsresult['secretarias'];
    $punidade = $rowsresult['unidade'];
    $preferencia = $rowsresult['referencia'];
    $pcad = $rowsresult['numcad'];

    $pdf-> SetFont ('Arial', 'I', 8);
    $pdf-> Cell(35,6, utf8_decode($psecretaria), 1,0, 'C', 0);
    $pdf-> Cell(30,6, utf8_decode($punidade), 1,0, 'C', 0);
    $pdf-> Cell(30,6, utf8_decode($preferencia), 1,0, 'C', 0);
    $pdf-> Cell(15,6, $pcad, 1,0, 'C', 0);
    $pdf-> Cell(60,6, "", 1,0, 'C', 0);
    $pdf-> Ln (6);
}

    mysqli_close ($conn);

// Mostramos o documento pdf no navegador
$pdf-> Output ('CadastrosAtivos','I');


?>