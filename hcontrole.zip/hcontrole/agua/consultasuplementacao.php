<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

?>

<body>
<br><br>
<form action="" method="POST">
    <tr>
    <td>Ano:</td>
        <td><input type="number" name="ano" id="ano" maxlength="4" required/></td>
    </tr>
    <tr>
    <td>Número de meses para terminar o ano:</td>
        <td><input type="number" name="meses" id="meses" maxlength="1" required/></td>
    </tr>
    <tr>
        <td align="right" colspan="2"><input type="submit" value="Pesquisar"></td>
    </tr>
</form>
    <br><br>
    <br><br>
<form>
    <table border=2>
        <tr>
            <td><b>Secretaria </b></td>
            <td><b>Unidade </b></td>
            <td><b>Ficha </b></td>
            <td><b>Dotação </b></td>
            <td><b>Valor Empenhado Inicial (a) </b></td>
            <td><b>Valor Suplementações (b) </b></td>
            <td><b>Valor Anulações (c) </b></td>
            <td><b>Valor Total Empenhado (a+b-c) </b></td>
            <td><b>Valor Pago Total </b></td>
            <td><b>Média Paga Total </b></td>
            <td><b>Soma Meses Maior Gasto (3 maiores meses) </b></td>
            <td><b>Média Meses Maior Gasto (3 maiores meses) </b></td>
            <td><b>Necessidade de Suplementação (S/N) </b></td>
        </tr>


<?php
    if (isset($_POST['ano']))
    {
        $ano = $_POST['ano'];
        $meses = $_POST['meses'];
        $consulta = "SELECT s.secretarias, 
                                u.unidade, 
                                e.ficha, 
                                e.dotacao, 
                                e.valor_inicial, 
                                valor_suplementar1, 
                                valor_suplementar2, 
                                valor_suplementar3, 
                                valor_suplementar4, 
                                valor_suplementar5, 
                                valor_suplementar6,
                                valor_anulacao1,
                                valor_anulacao2,
                                valor_anulacao3,
                                valor_anulacao4,
                                valor_anulacao5,
                                valor_anulacao6,
                                p.1, p.2, p.3,
                                p.4, p.5, p.6, p.7, p.8, p.9, p.10, p.11, p.12
                    FROM empenho e, secretarias s, unidades u, pagamento p
                    WHERE s.idsecretaria = e.codsecretaria
                    AND u.id = e.codund
                    AND p.codsec = s.idsecretaria
                    AND e.codsecretaria = p.codsec
                    AND p.codund = e.codund
                    AND e.ano = p.ano
                    AND e.ano = $ano";
        $result = mysqli_query($conn, $consulta);


        while($rowsresult=mysqli_fetch_array($result))
        {
            $inicial = $rowsresult['valor_inicial'];
            $somasuplementos = $rowsresult['valor_suplementar1'] + $rowsresult['valor_suplementar2'] + $rowsresult['valor_suplementar3'] + $rowsresult['valor_suplementar4'] + $rowsresult['valor_suplementar5'] + $rowsresult['valor_suplementar6'];
            $somaanulacoes = $rowsresult['valor_anulacao1'] + $rowsresult['valor_anulacao2'] + $rowsresult['valor_anulacao3'] + $rowsresult['valor_anulacao4'] + $rowsresult['valor_anulacao5'] + $rowsresult['valor_anulacao6'];
            $total = $inicial + $somasuplementos - $somaanulacoes;
            $totalpago = $rowsresult['1']+$rowsresult['2']+$rowsresult['3']+$rowsresult['4']+$rowsresult['5']+$rowsresult['6']+$rowsresult['7']+$rowsresult['8']+$rowsresult['9']+$rowsresult['10']+$rowsresult['11']+$rowsresult['12'];
            $mediapaga = $totalpago/12;
            $arraymaiorgasto = array($rowsresult['1'],$rowsresult['2'],$rowsresult['3'],$rowsresult['4'],$rowsresult['5'],$rowsresult['6'],$rowsresult['7'],$rowsresult['8'],$rowsresult['9'],$rowsresult['10'],$rowsresult['11'],$rowsresult['12']);
            rsort($arraymaiorgasto);
            $tresmaiores = array_slice($arraymaiorgasto,0,3);
            $somamaiorgasto = array_sum($tresmaiores);
            $mediamaiorgasto = $somamaiorgasto/3;
            $valornecessario = $mediamaiorgasto * $meses;
            $avaliasuplementacao = $total - $totalpago;
            if($avaliasuplementacao > $valornecessario)
            {
                $resposta = 'N - há disponibilidade de valores';
            }
            else{
                $suplementar = $valornecessario - $avaliasuplementacao;
                $resposta = 'S - Suplementar em: '.number_format($suplementar,2,',','.');
            }
            echo "<tr>";
            echo "<td>".$rowsresult['secretarias']."</td>";
            echo "<td>".$rowsresult['unidade']."</td>";
            echo "<td>".$rowsresult['ficha']."</td>";
            echo "<td>".$rowsresult['dotacao']."</td>";
            echo "<td>".number_format($inicial,2,',','.')."</td>";
            echo "<td>".number_format($somasuplementos,2,',','.')."</td>";
            echo "<td>".number_format($somaanulacoes,2,',','.')."</td>";
            echo "<td>".number_format($total,2,',','.')."</td>";
            echo "<td>".number_format($totalpago,2,',','.')."</td>";
            echo "<td>".number_format($mediapaga,2,',','.')."</td>";
            echo "<td>".number_format($somamaiorgasto,2,',','.')."</td>";
            echo "<td>".number_format($mediamaiorgasto,2,',','.')."</td>";
            echo "<td>".$resposta."</td>";
        }
            echo "</tr>";
        echo "</table>";
    }
?>
</form>
</body>