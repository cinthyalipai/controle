<?php
include ('../connection/conexao.php');
?>

<?php 
//error_reporting(0);

require ('../../../fpdf/fpdf.php');

set_time_limit(90);

$ano = $_POST['ano'];

$consulta = "SELECT s.secretarias, u.unidade, t.tipo, i.proprietario,
                p.numcad, i.numhidro, i.denomina, r.ruas, i.numero,
                b.bairros
            FROM imovel i, pasta p, secretarias s, unidades u, tipoprop t, ruas r, bairros b
            WHERE p.numcad = i.idcad AND
            s.idsecretaria = p.codsec AND
            u.id = p.codund AND
            t.id = i.codtipoprop AND
            r.idrua = i.codlogradouro AND
            b.idbairro = i.codbairro AND
            p.at$ano like 'Ativo'
            ORDER BY s.secretarias ASC, u.unidade ASC, t.tipo ASC, i.idcad ASC";
$result = mysqli_query($conn, $consulta);

$pdf = new FPDF('L','mm','Legal'); //instala classe para gerar documento
$pdf -> AddPage(); //adiciona pagina ao documento
$pdf->SetXY(10, 10);
$pdf-> SetFont ('Arial', 'B', 12); // cria o título da página
$pdf-> Cell (250,5, utf8_decode('Relação de Imóveis Ativos por Secretaria em '.$ano), 0,0, 'C');
$pdf-> Ln (10);
$pdf-> SetFillColor (232,232,232);
$pdf-> SetFont ('Arial', 'B', 7);
//células dos títulos das colunas
$pdf-> Cell (35,12, utf8_decode('Secretaria'), 1,0, 'C', 1);
$pdf-> Cell (20,12, utf8_decode('Unidade'), 1,0, 'C', 1);
$pdf-> Cell (35,12, utf8_decode('Tipo Imóvel'), 1,0, 'C', 1);
$pdf-> Cell (70,12, utf8_decode('Proprietário'), 1,0, 'C', 1);
$pdf-> Cell (20,12, utf8_decode('Núm Cadastro'), 1,0, 'C', 1);
$pdf-> Cell (20,12, utf8_decode('Hidrômetro'), 1,0, 'C', 1);
//$pdf-> Cell (50,12, utf8_decode('Denominação'), 1,0, 'C', 1);
$pdf-> Cell (50,12, utf8_decode('Endereço'), 1,0, 'C', 1);
$pdf-> Cell (15,12, utf8_decode('Número'), 1,0, 'C', 1);
$pdf-> Cell (50,12, utf8_decode('Bairro'), 1,0, 'C', 1);

$pdf-> Ln (10);

//comeca a listar a consulta
while($rowsresult=mysqli_fetch_array($result))
{
    $psecretaria = $rowsresult['secretarias'];
    $punidade = $rowsresult['unidade'];
    $ptipo = $rowsresult['tipo'];
    $pproprietario = $rowsresult['proprietario'];
    $pcad = $rowsresult['numcad'];
    $phidro = $rowsresult['numhidro'];
    //$pdenomina = $rowsresult['denomina'];
    $prua = $rowsresult['ruas'];
    $pnumero = $rowsresult['numero'];
    $pbairro = $rowsresult['bairros'];

    $pdf-> SetFont ('Arial', 'I', 8);
    $pdf-> Cell(35,10, utf8_decode($psecretaria), 0,0, 'C', 0);
    $pdf-> Cell(20,10, utf8_decode($punidade), 0,0, 'C', 0);
    $pdf-> Cell(35,10, utf8_decode($ptipo), 0,0, 'C', 0);
    $pdf-> Cell(70,10, utf8_decode($pproprietario), 0,0, 'L', 0);
    $pdf-> Cell(20,10, utf8_decode($pcad), 0,0, 'C', 0);
    $pdf-> Cell(20,10, utf8_decode($phidro), 0,0, 'C', 0);
    //$pdf-> Cell(50,10, utf8_decode($pdenomina), 0,0, 'L', 0);
    $pdf-> Cell(50,10, utf8_decode($prua), 0,0, 'L', 0);
    $pdf-> Cell(15,10, utf8_decode($pnumero), 0,0, 'C', 0);
    $pdf-> Cell(50,10, utf8_decode($pbairro), 0,0, 'L', 0);

    $pdf-> Ln (5);
}

    mysqli_close ($conn);

// Mostramos o documento pdf no navegador
$pdf-> Output ('ImoveisAtivos','I');