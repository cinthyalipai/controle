<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

?>

<?php
    if(isset($_POST['alteracao']))
    {
        if ($_POST['alteracao']==1 and $_POST['nome_sec']<>"Selecione Secretaria" and $_POST['nome_und']<>"Selecione Unidade")
        {
            $secretaria = $_POST['nome_sec'];
            $unidade = $_POST['nome_und'];
            $hoje=date("Y-m-d");
            $ano = date('Y');
            
            $consulta = "SELECT codsec, codund, ano 
                        FROM pagamento
                        WHERE codsec = $secretaria AND
                            codund = $unidade AND
                            ano = $ano";
            $result_consulta = mysqli_query($conn, $consulta);
            $linhas = mysqli_fetch_array($result_consulta);

            if($linhas > 0)
            {
                echo "<br><br>";
                echo "Este cadastro já foi realizado anteriormente";
            }
            else 
            {
                $insere = "INSERT INTO pagamento (codsec, codund, ano)
                            VALUES ($secretaria, $unidade, $ano)";
                $result_insere = mysqli_query($conn, $insere);
            }
            
            echo "<br><br><br>";
            echo "<table border='1'>";
            echo "<tr>";
            echo "<td><b> Secretaria </b></td>";
            echo "<td><b> Unidade </b></td>";
            echo "</tr>";

            $mostrapesquisa = "SELECT s.secretarias, u.unidade 
                                FROM pagamento p, secretarias s, unidades u
                                WHERE p.codsec = s.idsecretaria AND
                                        u.id = p.codund AND
                                        p.ano = $ano";
            $result_mostrapesquisa = mysqli_query($conn, $mostrapesquisa);

            while ($rows_pesquisa = mysqli_fetch_array($result_mostrapesquisa))
            {
                echo "<tr>";
                echo "<td>".$rows_pesquisa['secretarias']."</td>";
                echo "<td>".$rows_pesquisa['unidade']."</td>";
            }
                echo "</tr>";
                echo "</table>";


        }
        elseif($_POST['alteracao']==1 and $_POST['nome_sec']=="Selecione Secretaria" and $_POST['nome_und']<>"Selecione Unidade")
            echo "Favor Selecionar Secretaria";
        elseif($_POST['alteracao']==1 and $_POST['nome_sec']<>"Selecione Secretaria" and $_POST['nome_und']=="Selecione Unidade")
            echo "Definir a Unidade de Custos";
        elseif($_POST['alteracao']==1 and $_POST['nome_sec']=="Selecione Secretaria" and $_POST['nome_und']=="Selecione Unidade")
            echo "Definir a Secretaria e a Unidade de Custos";   
        elseif ($_POST['alteracao'] == 2)
        {
            if(isset($_POST['mes']))
            {
            $hoje=date("Y-m-d");
            $ano = date('Y');
            $mes = $_POST['mes'];
            echo "<br><br>";
            echo"<form name='digita' method='POST' action='processapgto.php'>";
            echo "<table border='2'>";
                echo "<th colspan='30'>Pagamento Mensal - ".$mes."/".$ano."</th>";
                echo "<tr>";
                    echo "<td><b>Secretaria</b></td>";
                    echo "<td><b>Unidade</b></td>";
                    echo "<td><b>Valor Pago no Mês</b></td>";
                echo "</tr>";
            
            $listapagamento = "SELECT p.idpgto, s.secretarias, u.unidade, p.$mes as messelec 
                                FROM pagamento p, secretarias s, unidades u
                                WHERE p.codsec = s.idsecretaria AND
                                        u.id = p.codund AND
                                        p.ano = $ano";
            $result_listapgto = mysqli_query($conn, $listapagamento);

            while($rows_lista = mysqli_fetch_array($result_listapgto))
            {  
            ?>
                <tr>
                <input type='hidden' name='mes' id='mes' value ="<?php echo $mes?>" >
                <input type='hidden' name='ano' id='ano' value ="<?php echo $ano?>" >
                <input type='hidden' name='idpgto[]' id='idpgto' value ="<?php echo $rows_lista['idpgto']?>" >
                <input type='hidden' name='valoranterior[]' id='valoranterior' value ="<?php echo $valor?>" >
                <td><input type='hidden' name='secretarias[]' id='secretarias' value ="<?php echo $rows_lista['secretarias']?>" ><?php echo $rows_lista['secretarias']?></td>
                <td><input type='hidden' name='unidade[]' id='unidade' value ="<?php echo $rows_lista['unidade']?>" ><?php echo $rows_lista['unidade']?></td>
                <td><input type='number' name='novovalor[]' id='novovalor' value ="<?php echo $rows_lista['messelec'] ?>" step=".01"></td>
                </tr>
            <?php
                
            }
                echo "<tr>";
                echo "<td colspan='3' align='right'><input type='submit' name='enviar' id='enviar' maxlength='15' value ='Enviar'></td>";
                echo "</tr>";
            } 
        }
    }
?>