<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');
require('../../../fpdf/fpdf.php');

?>

<body>
<br><br>
<form action="pdfsuplementacao.php" method="POST">
    <table>
        <tr>
            <td>Ano:</td>
            <td><input type="number" name="ano" id="ano" maxlength="4" required/></td>
        </tr>
        <tr>
            <td>Número de meses para terminar o ano:</td>
            <td><input type="number" name="meses" id="meses" maxlength="1" required/></td>
        </tr>
        <tr>
            <td align="center" colspan="2"><input type="submit" value="Gerar PDF"></td>
        </tr>
    </table>
</form>