<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

?>
<br><br>
<form method="POST" action="atualizasec.php">
    Insira Número do Cadastro:<input type="text" name="idcad" placeholder="Número Cadastro"> <br><br>
    Insira Ano para pesquisa:<input type="text" name="ano" placeholder="Ano"><br><br>
    Selecione Tipo de Funcionamento: <select name="funciona">
                                        <option value='Ativo'>Ativo</option>
                                        <option value='Inativo'>Inativo</option>
                                    </select><br><br>
    <input type="submit" name="enviar" value="Enviar">
    <input type="reset" name="limpar" value="Limpar Pesquisa"> <br> <br>
    
<?php

    if (empty($_POST['idcad']) and empty($_POST['ano']) and empty($_POST['funciona']))

        echo "Inserir dados para a pesquisa";

    elseif (!empty($_POST['idcad']) and empty($_POST['ano']) and empty($_POST['funciona']))

        echo "Cadastro ou Ano não informados";

    elseif (empty ($_POST['idcad']) and !empty($_POST['ano'])and empty($_POST['funciona']))

        echo "Cadastro ou Ano não informados";

    elseif (empty ($_POST['idcad']) and empty($_POST['ano'])and !empty($_POST['funciona']))

        echo "Cadastro ou Ano não informados";

    elseif (!empty($_POST['idcad']) and !empty($_POST['ano'])and !empty($_POST['funciona'])) 
    { 

     echo "<body>";

     echo"<table border='1'>";
     echo"<tr>";
         echo"<td><b>Cadastro</b></td>";              
         echo"<td><b>Hidrometro</b></td>"; 
         echo"<td><b>Tipo Contrato</b></td>";             
         echo"<td><b>Proprietario Imovel</b></td>";
         echo"<td><b>Nome do Predio</b></td>";
         echo"<td><b>Secretaria</b></td>";
         echo"<td><b>Unidade</b></td>";
         echo"<td><b>Ref Cobrança</b></td>";
         echo"<td><b>Funcionamento</b></td>";
     echo"</tr>";

     $idcad = $_POST['idcad'];
     $ano = $_POST['ano'];
     $funciona = $_POST['funciona'];

     echo "Cadastro Pesquisado: Todos aqueles que contenham " .$idcad;
     echo "<br>";
     echo "Ano Pesquisado: ".$ano;
     echo "<br>";
     echo "Situação: ".$funciona;
     echo "<br>";
     echo "<br>";

     $sql_cad = "SELECT p.idpasta, i.idcad, i.numhidro, t.tipo, i.proprietario, i.denomina, r.ruas, i.numero, b.bairros, s.secretarias, u.unidade, f.referencia, p.at$ano as funcionamento
     FROM imovel i, pasta p, tipoprop t, ruas r, bairros b, secretarias s, unidades u, referencia f
     WHERE i.idcad = p.numcad AND
             t.id = i.codtipoprop AND
             r.idrua = i.codlogradouro AND
             b.idbairro = i.codbairro AND
             s.idsecretaria = p.codsec AND
             u.id = p.codund AND
             f.idref = p.codref AND
             p.at$ano LIKE '$funciona' AND
             p.numcad LIKE '%$idcad%'
     ORDER BY p.idpasta ASC";  
$resultado_cad = mysqli_query($conn, $sql_cad);
$rows_cad = mysqli_fetch_array($resultado_cad);

$idpasta=$rows_cad['idpasta'];
 $idcad=$rows_cad['idcad'];
 $hidrometro=$rows_cad['numhidro'];
 $tipo_prop=$rows_cad['tipo'];
 $nome_prop=$rows_cad['proprietario'];
 $denomina=$rows_cad['denomina'];
 $secretaria=$rows_cad['secretarias'];
 $unidade=$rows_cad['unidade'];
 $referencia=$rows_cad['referencia'];
 $funcionamento=$rows_cad['funcionamento'];
 do
{
 echo "<tr>";
 echo "<td><a href='alterasec.php?ano=".$ano."&&idpasta=".$rows_cad['idpasta']."'>".$rows_cad['idcad']."</td>";
 echo "<td>".$rows_cad['numhidro']."</td>";
 echo "<td>".$rows_cad['tipo']."</td>";
 echo "<td>".$rows_cad['proprietario']."</td>";
 echo "<td>".$rows_cad['denomina']."</td>";
 echo "<td>".$rows_cad['secretarias']."</td>";
 echo "<td>".$rows_cad['unidade']."</td>";
 echo "<td>".$rows_cad['referencia']."</td>";
 echo "<td>".$rows_cad['funcionamento']."</td>";
 echo "</tr>";
}
 while($rows_cad = mysqli_fetch_array($resultado_cad));

echo "</table>";


}
else 
    {
        unset ($idcad);
        unset ($ano);
    }

?>