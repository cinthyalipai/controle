<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

?>

<?php

if(isset($_POST['dotacao']) and isset($_POST['ficha']) and isset($_POST['empinicial']) and isset($_POST['valorinicial']))
{
    $novasecretaria = $_POST['secretaria'];
    $novaunidade = $_POST['unidade'];
    $incluiano = $_POST['ano'];
    $dotacao = $_POST['dotacao'];
    $ficha = $_POST['ficha'];
    $empenho = $_POST['empinicial'];
    $valor = $_POST['valorinicial'];


    $cadastraempenho = "INSERT INTO empenho (codsecretaria, codund, ano, dotacao, ficha, num_empenho, valor_inicial) 
                        VALUES ('".$novasecretaria."','".$novaunidade."','".$incluiano."', '".$dotacao."','".$ficha."','".$empenho."','".$valor."' )";
    $resultcadastro = mysqli_query($conn, $cadastraempenho);


    if (!$resultcadastro) echo "Dados não foram gravados"; else echo "Dados gravados com sucesso";
}

?>

