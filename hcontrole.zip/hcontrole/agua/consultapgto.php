<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

?>

<body>
<br><br>
<form action="" method="POST">
    <tr>
    <td>Ano:</td>
        <td><input type="number" name="ano" id="ano" maxlength="4" required/></td>
    </tr>
    <tr>
        <td align="right" colspan="2"><input type="submit" value="Pesquisar"></td>
    </tr>
</form>
    <br><br>
    <br><br>
<form>
    <table border=2>
        <tr>
            <td><b>Secretaria </b></td>
            <td><b>Unidade </b></td>
            <td><b>Janeiro </b></td>
            <td><b>Fevereiro </b></td>
            <td><b>Março</b></td>
            <td><b>Abril</b></td>
            <td><b>Maio</b></td>
            <td><b>Junho</b></td>
            <td><b>Julho</b></td>
            <td><b>Agosto</b></td>
            <td><b>Setembro</b></td>
            <td><b>Outubro</b></td>
            <td><b>Novembro</b></td>
            <td><b>Dezembro</b></td>
        </tr>


<?php
    if (isset($_POST['ano']))
    {
        $ano = $_POST['ano'];
        $consulta = "SELECT s.secretarias, 
                                u.unidade, 
                                p.1, p.2, p.3,
                                p.4, p.5, p.6, p.7, p.8, p.9, p.10, p.11, p.12
                    FROM secretarias s, unidades u, pagamento p
                    WHERE p.codsec = s.idsecretaria
                    AND u.id = p.codund
                    AND p.ano = $ano";
        $result = mysqli_query($conn, $consulta);

        echo "Ano Pesquisado: ".$ano; echo "<br><br>";
        while($rowsresult=mysqli_fetch_array($result))
        {
            
            echo "<tr>";
            echo "<td>".$rowsresult['secretarias']."</td>";
            echo "<td>".$rowsresult['unidade']."</td>";

            if (is_null($rowsresult['1']))
            {
                echo "<td> 0,00 </td>";
            }
            else{
                echo "<td>".number_format($rowsresult['1'],2,',','.')."</td>";
            }

            if (is_null($rowsresult['2']))
            {
                echo "<td> 0,00 </td>";
            }
            else{
                echo "<td>".number_format($rowsresult['2'],2,',','.')."</td>";
            }
            
            if (is_null($rowsresult['3']))
            {
                echo "<td> 0,00 </td>";
            }
            else{
                echo "<td>".number_format($rowsresult['3'],2,',','.')."</td>";
            }
            
            if (is_null($rowsresult['4']))
            {
                echo "<td> 0,00 </td>";
            }
            else{
                echo "<td>".number_format($rowsresult['4'],2,',','.')."</td>";
            }
            
            if (is_null($rowsresult['5']))
            {
                echo "<td> 0,00 </td>";
            }
            else{
                echo "<td>".number_format($rowsresult['5'],2,',','.')."</td>";
            }

            if (is_null($rowsresult['6']))
            {
                echo "<td> 0,00 </td>";
            }
            else{
                echo "<td>".number_format($rowsresult['6'],2,',','.')."</td>";
            }

            if (is_null($rowsresult['7']))
            {
                echo "<td> 0,00 </td>";
            }
            else{
                echo "<td>".number_format($rowsresult['7'],2,',','.')."</td>";
            }

            if (is_null($rowsresult['8']))
            {
                echo "<td> 0,00 </td>";
            }
            else{
                echo "<td>".number_format($rowsresult['8'],2,',','.')."</td>";
            }

            if (is_null($rowsresult['9']))
            {
                echo "<td> 0,00 </td>";
            }
            else{
                echo "<td>".number_format($rowsresult['9'],2,',','.')."</td>";
            }

            if (is_null($rowsresult['10']))
            {
                echo "<td> 0,00 </td>";
            }
            else{
                echo "<td>".number_format($rowsresult['10'],2,',','.')."</td>";
            }

            if (is_null($rowsresult['11']))
            {
                echo "<td> 0,00 </td>";
            }
            else{
                echo "<td>".number_format($rowsresult['11'],2,',','.')."</td>";
            }

            if (is_null($rowsresult['12']))
            {
                echo "<td> 0,00 </td>";
            }
            else{
                echo "<td>".number_format($rowsresult['12'],2,',','.')."</td>";
            }

        }
            echo "</tr>";
        echo "</table>";
    }
?>
</form>
</body>