<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

$tiposec = mysqli_query($conn, "SELECT idsecretaria, secretarias FROM secretarias");
?>

<head>
    <meta charset="utf-8">
    <title>Digitação de Consumo</title>
</head>

<body>
    <br>
    <form name="pesquisa" method="POST" action='' >
        <table>
            <th colspan='2'>Digitação Mensal de Consumo</th>
            <tr>
            <td>Secretaria:</td>
                <td>
                    <select name="nome_sec"> 
                        <option>Selecione Secretaria</option>
                        <?php while($secretaria = mysqli_fetch_array($tiposec)) 
                        { ?> 
                            <option value="<?php echo $secretaria['idsecretaria'] ?>"><?php echo $secretaria['secretarias'] ?></option> 
                        <?php } ?> 
                    </select>
                </td>
            </tr>
            <tr>
                <td>Ano:</td>
                <td><input type="text" name="ano" id="ano" maxlength="4" required/></td>
            </tr>
            <tr>
                <td>Mes Vencimento:</td>
                <td>
                    <select name="mes">
                        <option value="1">Janeiro</option>
                        <option value="2">Fevereiro</option>
                        <option value="3">Março</option>
                        <option value="4">Abril</option>
                        <option value="5">Maio</option>
                        <option value="6">Junho</option>
                        <option value="7">Julho</option>
                        <option value="8">Agosto</option>
                        <option value="9">Setembro</option>
                        <option value="10">Outubro</option>
                        <option value="11">Novembro</option>
                        <option value="12">Dezembro</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Status:</td>
                <td>
                    <select name="opt">
                        <option value="Ativo">Ativo</option>
                        <option value="Inativo">Inativo</option>
                    </select>
                </td>
            </tr>
                <td></td><td></td><td></td><td></td>
                <td align="right" colspan="2"><input type="submit" value="Pesquisar"></td>
            </tr>
        </table>
    </form>

    <br><br><br>
    
<?php

if (isset($_POST['ano']) and $_POST['nome_sec']=="Selecione Secretaria")
    {
    echo "<br><br><br><h3 align='center'> Favor Selecionar Secretaria </h3>";
    }

elseif (isset($_POST['ano']) and $_POST['nome_sec']<>"Selecione Secretaria")
    {
        $ano = $_POST['ano'];
        $secretaria = $_POST['nome_sec'];
        $mes = $_POST['mes'];
        $opt = $_POST['opt'];

        echo"<form name='digita' method='POST' action='gravaconsumo.php'>";
        echo "<table border='2'>";
            echo "<th colspan='30'>Consumo Mensal - ".$mes."/".$ano." </th>";
            echo "<tr>";
                echo "<td><b>Cadastro</b></td>";
                echo "<td><b>Referência</b></td>";
                echo "<td><b>Consumo m³</b></td>";
                echo "<td><b>Valor R$</b></td>";
            echo "</tr>";

            $messelec = "SELECT c.idconsumo, v.idvalor, p.numcad, r.referencia, c.$mes as consumo, v.$mes as valor
                        FROM pasta p, consumo c, valores v, referencia r
                        WHERE p.idpasta = c.codpasta
                        AND c.idconsumo = v.idvalor
                        AND r.idref = p.codref
                        AND v.ano=$ano
                        AND p.codsec = $secretaria
                        AND p.at$ano like '".$opt."'
                        ORDER BY r.idref DESC, p.numcad ASC";
            $retornamesselec = mysqli_query($conn, $messelec);
        
            while ($rows_messelec = mysqli_fetch_array($retornamesselec))
            {
                $consumo = $rows_messelec['consumo'];
                $valor = $rows_messelec['valor'];
                $idconsumo = $rows_messelec['idconsumo'];
                $idvalor = $rows_messelec['idvalor'];
            ?>
                
            <tr>
                <input type='hidden' name='mes' id='mes' maxlength='15' value ="<?php echo $mes?>" >
                <input type='hidden' name='idconsumo[]' id='idconsumo' maxlength='6' value ="<?php echo $idconsumo?>">
                <input type='hidden' name='idvalor[]' id='idvalor' maxlength='6' value ="<?php echo $idvalor?>">
                <input type='hidden' name='consumoanterior[]' id='consumoanterior' maxlength='6' value ="<?php echo $consumo?>">
                <input type='hidden' name='valoranterior[]' id='valoranterior' maxlength='6' value ="<?php echo $valor?>">
                <td><input type='hidden' name='numcad[]' id='numcad' maxlength='6' value ="<?php echo $rows_messelec['numcad']?>" ><?php echo $rows_messelec['numcad']?></td>
                <td><input type='hidden' name='referencia[]' id='referencia' maxlength='6' value ="<?php echo $rows_messelec['referencia']?>" ><?php echo $rows_messelec['referencia']?></td>
                <td><input type='number' name='digconsumo[]' id='digconsumo' maxlength='6' value ="<?php echo $consumo ?>" ></td>
                <td><input type='number' name='digvalor[]' id='digvalor' maxlength='15' value ="<?php echo $valor ?>" step=".01"></td> 


            <?php
                
            }
            echo "<tr>";
            echo "<td colspan='4' align='right'><input type='submit' name='enviar' id='enviar' maxlength='15' value ='Enviar'></td>";
            echo "</tr>";
            
            
            
    }
?>