<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');
require('../../../fpdf/fpdf.php');

?>

<body>
<br><br>
<form action="pdfimovelativo.php" method="POST">
    <table>
        <tr>
            <td>Ano:</td>
            <td><input type="number" name="ano" id="ano" maxlength="4" required/></td>
            <td align="center" colspan="2"><input type="submit" value="Gerar PDF"></td>
        </tr>
    </table>
</form>