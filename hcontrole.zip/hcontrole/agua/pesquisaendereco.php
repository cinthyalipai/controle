<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');


$tipoend = mysqli_query($conn, "SELECT idrua, ruas FROM ruas");
$tipobairro = mysqli_query($conn, "SELECT idbairro, bairros FROM bairros");


?>
<head>
    <meta charset="utf-8">
    <title>Pesquisa Por Endereço</title>
</head>
<body>
    <br>
    <form name="pesquisa" method="POST" action="pesquisaendereco.php">
        <table>
            <th colspan='2'>Pesquisa de Prédios por Endereço</th>
            <tr>
                <td>Endereço:</td>
                <td>
                    <select name="nome_rua"> 
                        <option>Selecione Endereço</option>
                        <?php while($logradouro = mysqli_fetch_array($tipoend)) 
                        { ?> 
                            <option value="<?php echo $logradouro['idrua'] ?>"><?php echo $logradouro['ruas'] ?></option> 
                        <?php } ?> 
                    </select>
                </td>
            </tr>
            <tr>
                <td>Bairro:</td>
                <td>
                <select name="nome_bairro"> 
                    <option>Selecione Bairro</option>
                    <?php while($bairro = mysqli_fetch_array($tipobairro)) 
                    { ?> 
                        <option value="<?php echo $bairro['idbairro'] ?>"><?php echo $bairro['bairros'] ?></option>
                    <?php } ?> 
                </select>
            </td> 
            </tr>
            <tr>
                <td>Ano:</td>
                <td><input type="text" name="ano" id="ano" maxlength="4" required/></td>
            </tr>
            <tr>
                <td align="right" colspan="2"><input type="submit" value="Pesquisar"></td>
            </tr>
        </table>
    </form>

<?php

set_time_limit(180);

if (empty($_POST['nome_rua']) and empty($_POST['nome_bairro']) and empty($_POST['ano']))

    echo "Inserir dados para a pesquisa";

elseif (empty($_POST['nome_rua']) and empty($_POST['nome_bairro']) and !empty($_POST['ano']))

echo "Favor preencher todos os dados";    

elseif (!empty($_POST['nome_rua']) and !empty($_POST['nome_bairro']) and !empty($_POST['ano']))
{ 

    $nomerua = $_POST['nome_rua'];
    $nomebairro = $_POST['nome_bairro'];
    $ano = $_POST['ano'];

    echo "<br>";
    echo"<table border='1'>";
    echo"<tr>";
        echo"<td><b>Cadastro</b></td>";              
        echo"<td><b>Hidrometro</b></td>"; 
        echo"<td><b>Tipo Contrato</b></td>";             
        echo"<td><b>Proprietario Imovel</b></td>";
        echo"<td><b>Nome do Predio</b></td>";
        echo"<td><b>Endereco</b></td>";
        echo"<td><b>Numero</b></td>";          
        echo"<td><b>Bairro</b></td>";
        echo"<td><b>Secretaria</b></td>";
        echo"<td><b>Unidade</b></td>";
        echo"<td><b>Ref Cobrança</b></td>";
        echo"<td><b>Funcionamento em ".$ano."</b></td>";
    echo"</tr>";

    If (($nomerua <> "Selecione Endereço") AND ($nomebairro <> "Selecione Bairro")) 
    {
        $sqlpesquisa = "SELECT i.idcad, i.numhidro, t.tipo, i.proprietario, i.denomina, r.ruas, i.numero, b.bairros, s.secretarias, u.unidade, f.referencia, p.at$ano as funcionamento
                        FROM imovel i, tipoprop t, ruas r, bairros b, pasta p, secretarias s, unidades u, referencia f
                        WHERE i.codtipoprop = t.id AND
                                i.codlogradouro = r.idrua AND
                                i.codbairro = b.idbairro AND
                                p.numcad = i.idcad AND
                                p.codsec = s.idsecretaria AND
                                p.codund = u.id AND
                                p.codref = f.idref AND
                                (i.codlogradouro = $nomerua OR i.codbairro = $nomebairro)
                        ORDER BY p.at$ano ASC, i.idcad ASC";
                        
        $resultado_pesquisa = mysqli_query($conn, $sqlpesquisa);
        $rows_pesquisa = mysqli_fetch_array($resultado_pesquisa);

        if($rows_pesquisa >0){
            $idcad=$rows_pesquisa['idcad'];
            $hidrometro=$rows_pesquisa['numhidro'];
            $tipo_prop=$rows_pesquisa['tipo'];
            $nome_prop=$rows_pesquisa['proprietario'];
            $denomina=$rows_pesquisa['denomina'];
            $logradouro=$rows_pesquisa['ruas'];
            $numero=$rows_pesquisa['numero'];
            $bairro=$rows_pesquisa['bairros'];
            $secretaria=$rows_pesquisa['secretarias'];
            $unidade=$rows_pesquisa['unidade'];
            $referencia=$rows_pesquisa['referencia'];
            $funcionamento=$rows_pesquisa['funcionamento'];
                do
                {
                    echo "<tr>";
                    echo "<td>".$rows_pesquisa['idcad']."</td>";
                    echo "<td>".$rows_pesquisa['numhidro']."</td>";
                    echo "<td>".$rows_pesquisa['tipo']."</td>";
                    echo "<td>".$rows_pesquisa['proprietario']."</td>";
                    echo "<td>".$rows_pesquisa['denomina']."</td>";
                    echo "<td>".$rows_pesquisa['ruas']."</td>";
                    echo "<td>".$rows_pesquisa['numero']."</td>";
                    echo "<td>".$rows_pesquisa['bairros']."</td>";
                    echo "<td>".$rows_pesquisa['secretarias']."</td>";
                    echo "<td>".$rows_pesquisa['unidade']."</td>";
                    echo "<td>".$rows_pesquisa['referencia']."</td>";
                    echo "<td>".$rows_pesquisa['funcionamento']."</td>";
                    echo "</tr>";
                } while($rows_pesquisa = mysqli_fetch_array($resultado_pesquisa));
        } 
    }  elseif (($nomerua <> "Selecione Endereço") and ($nomebairro == "Selecione Bairro")) 
    {
        $sqlpesquisa = "SELECT i.idcad, i.numhidro, t.tipo, i.proprietario, i.denomina, r.ruas, i.numero, b.bairros, s.secretarias, u.unidade, f.referencia, p.at$ano as funcionamento
                    FROM imovel i, tipoprop t, ruas r, bairros b, pasta p, secretarias s, unidades u, referencia f
                    WHERE i.codtipoprop = t.id AND
                            i.codlogradouro = r.idrua AND
                            i.codbairro = b.idbairro AND
                            p.numcad = i.idcad AND
                            p.codsec = s.idsecretaria AND
                            p.codund = u.id AND
                            p.codref = f.idref AND
                            i.codlogradouro = $nomerua
                    ORDER BY p.at$ano ASC, i.idcad ASC";
                    
        $resultado_pesquisa = mysqli_query($conn, $sqlpesquisa);
        $rows_pesquisa = mysqli_fetch_array($resultado_pesquisa);

        if($rows_pesquisa >0){
            $idcad=$rows_pesquisa['idcad'];
            $hidrometro=$rows_pesquisa['numhidro'];
            $tipo_prop=$rows_pesquisa['tipo'];
            $nome_prop=$rows_pesquisa['proprietario'];
            $denomina=$rows_pesquisa['denomina'];
            $logradouro=$rows_pesquisa['ruas'];
            $numero=$rows_pesquisa['numero'];
            $bairro=$rows_pesquisa['bairros'];
            $secretaria=$rows_pesquisa['secretarias'];
            $unidade=$rows_pesquisa['unidade'];
            $referencia=$rows_pesquisa['referencia'];
            $funcionamento=$rows_pesquisa['funcionamento'];
                do
                {
                    echo "<tr>";
                    echo "<td>".$rows_pesquisa['idcad']."</td>";
                    echo "<td>".$rows_pesquisa['numhidro']."</td>";
                    echo "<td>".$rows_pesquisa['tipo']."</td>";
                    echo "<td>".$rows_pesquisa['proprietario']."</td>";
                    echo "<td>".$rows_pesquisa['denomina']."</td>";
                    echo "<td>".$rows_pesquisa['ruas']."</td>";
                    echo "<td>".$rows_pesquisa['numero']."</td>";
                    echo "<td>".$rows_pesquisa['bairros']."</td>";
                    echo "<td>".$rows_pesquisa['secretarias']."</td>";
                    echo "<td>".$rows_pesquisa['unidade']."</td>";
                    echo "<td>".$rows_pesquisa['referencia']."</td>";
                    echo "<td>".$rows_pesquisa['funcionamento']."</td>";
                    echo "</tr>";
                } while($rows_pesquisa = mysqli_fetch_array($resultado_pesquisa));}

    } elseif (($nomerua == "Selecione Endereço") and ($nomebairro <> "Selecione Bairro"))
    {
        $sqlpesquisa = "SELECT i.idcad, i.numhidro, t.tipo, i.proprietario, i.denomina, r.ruas, i.numero, b.bairros, s.secretarias, u.unidade, f.referencia, p.at$ano as funcionamento
                    FROM imovel i, tipoprop t, ruas r, bairros b, pasta p, secretarias s, unidades u, referencia f
                    WHERE i.codtipoprop = t.id AND
                            i.codlogradouro = r.idrua AND
                            i.codbairro = b.idbairro AND
                            p.numcad = i.idcad AND
                            p.codsec = s.idsecretaria AND
                            p.codund = u.id AND
                            p.codref = f.idref AND
                            i.codbairro = $nomebairro
                    ORDER BY p.at$ano ASC, i.idcad ASC";
                    
        $resultado_pesquisa = mysqli_query($conn, $sqlpesquisa);
        $rows_pesquisa = mysqli_fetch_array($resultado_pesquisa);

        if($rows_pesquisa >0){
            $idcad=$rows_pesquisa['idcad'];
            $hidrometro=$rows_pesquisa['numhidro'];
            $tipo_prop=$rows_pesquisa['tipo'];
            $nome_prop=$rows_pesquisa['proprietario'];
            $denomina=$rows_pesquisa['denomina'];
            $logradouro=$rows_pesquisa['ruas'];
            $numero=$rows_pesquisa['numero'];
            $bairro=$rows_pesquisa['bairros'];
            $secretaria=$rows_pesquisa['secretarias'];
            $unidade=$rows_pesquisa['unidade'];
            $referencia=$rows_pesquisa['referencia'];
            $funcionamento=$rows_pesquisa['funcionamento'];
                do
                {
                    echo "<tr>";
                    echo "<td>".$rows_pesquisa['idcad']."</td>";
                    echo "<td>".$rows_pesquisa['numhidro']."</td>";
                    echo "<td>".$rows_pesquisa['tipo']."</td>";
                    echo "<td>".$rows_pesquisa['proprietario']."</td>";
                    echo "<td>".$rows_pesquisa['denomina']."</td>";
                    echo "<td>".$rows_pesquisa['ruas']."</td>";
                    echo "<td>".$rows_pesquisa['numero']."</td>";
                    echo "<td>".$rows_pesquisa['bairros']."</td>";
                    echo "<td>".$rows_pesquisa['secretarias']."</td>";
                    echo "<td>".$rows_pesquisa['unidade']."</td>";
                    echo "<td>".$rows_pesquisa['referencia']."</td>";
                    echo "<td>".$rows_pesquisa['funcionamento']."</td>";
                    echo "</tr>";
                } while($rows_pesquisa = mysqli_fetch_array($resultado_pesquisa));}
    }
    else {
        echo "<h3 align='center'> Não foram encontrados valores para os dados pesquisados.</h3>";
        } 
        
    }
?>

</body>