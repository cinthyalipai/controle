<?php
include ('../connection/conexao.php');
?>

<?php 
//error_reporting (0);


require ('../../../fpdf/fpdf.php');


$ano = $_POST['ano'];
$meses = $_POST['meses'];
$consulta = "SELECT s.secretarias, 
                        u.unidade, 
                        e.ficha, 
                        e.dotacao, 
                        e.valor_inicial, 
                        valor_suplementar1, 
                        valor_suplementar2, 
                        valor_suplementar3, 
                        valor_suplementar4, 
                        valor_suplementar5, 
                        valor_suplementar6,
                        valor_anulacao1,
                        valor_anulacao2,
                        valor_anulacao3,
                        valor_anulacao4,
                        valor_anulacao5,
                        valor_anulacao6,
                        p.1, p.2, p.3,
                        p.4, p.5, p.6, p.7, p.8, p.9, p.10, p.11, p.12
            FROM empenho e, secretarias s, unidades u, pagamento p
            WHERE s.idsecretaria = e.codsecretaria
            AND u.id = e.codund
            AND p.codsec = s.idsecretaria
            AND e.codsecretaria = p.codsec
            AND p.codund = e.codund
            AND e.ano = p.ano
            AND e.ano = $ano";
$result = mysqli_query($conn, $consulta);

$pdf = new FPDF('L','mm','A4'); //instala classe para gerar documento
$pdf -> AddPage(); //adiciona pagina ao documento
$y_axis_initial = 25; //margem superior em 25 pixels
$pdf-> SetFont ('Arial', 'B', 12); // cria o título da página
$pdf-> Cell (40,6, '', 0,0, 'C');
$pdf-> Cell (100,5, utf8_decode('Análise de Suplementacao de Valores'), 1.0, 'C');
$pdf-> Ln (10);
$pdf-> SetFillColor (232,232,232);
$pdf-> SetFont ('Arial', 'B', 10);
//células dos títulos das colunas
$pdf-> Cell (50,6, utf8_decode('Secretaria'), 1.0, 'C', 1);
$pdf-> Cell (50,6, utf8_decode('Unidade'), 1.0, 'C', 1);
$pdf-> Cell (50,6, utf8_decode('Ficha'), 1.0, 'C', 1);
$pdf-> Cell (50,6, utf8_decode('Dotação'), 1.0, 'C', 1);
$pdf-> Cell (50,6, utf8_decode('Valor Empenhado Inicial (a)'), 1.0, 'C', 1);
$pdf-> Cell (50,6, utf8_decode('Valor Suplementações (b)'), 1.0, 'C', 1);
$pdf-> Cell (50,6, utf8_decode('Valor Anulações (c)'), 1.0, 'C', 1);
$pdf-> Cell (50,6, utf8_decode('Valor Total Empenhado (a+b-c)'), 1.0, 'C', 1);
$pdf-> Cell (50,6, utf8_decode('Valor Pago Total'), 1.0, 'C', 1);
$pdf-> Cell (50,6, utf8_decode('Média Paga Total'), 1.0, 'C', 1);
$pdf-> Cell (50,6, utf8_decode('Soma Meses Maior Gasto (3 maiores meses)'), 1.0, 'C', 1);
$pdf-> Cell (50,6, utf8_decode('Média Meses Maior Gasto (3 maiores meses)'), 1.0, 'C', 1);
$pdf-> Cell (50,6, utf8_decode('Necessidade de Suplementação (S/N)'), 1.0, 'C', 1);
$pdf-> Ln (10);

//comeca a listar a consulta
while($rowsresult=mysqli_fetch_array($result))
        {
            $inicial = $rowsresult['valor_inicial'];
            $somasuplementos = $rowsresult['valor_suplementar1'] + $rowsresult['valor_suplementar2'] + $rowsresult['valor_suplementar3'] + $rowsresult['valor_suplementar4'] + $rowsresult['valor_suplementar5'] + $rowsresult['valor_suplementar6'];
            $somaanulacoes = $rowsresult['valor_anulacao1'] + $rowsresult['valor_anulacao2'] + $rowsresult['valor_anulacao3'] + $rowsresult['valor_anulacao4'] + $rowsresult['valor_anulacao5'] + $rowsresult['valor_anulacao6'];
            $total = $inicial + $somasuplementos - $somaanulacoes;
            $totalpago = $rowsresult['1']+$rowsresult['2']+$rowsresult['3']+$rowsresult['4']+$rowsresult['5']+$rowsresult['6']+$rowsresult['7']+$rowsresult['8']+$rowsresult['9']+$rowsresult['10']+$rowsresult['11']+$rowsresult['12'];
            $mediapaga = $totalpago/12;
            $arraymaiorgasto = array($rowsresult['1'],$rowsresult['2'],$rowsresult['3'],$rowsresult['4'],$rowsresult['5'],$rowsresult['6'],$rowsresult['7'],$rowsresult['8'],$rowsresult['9'],$rowsresult['10'],$rowsresult['11'],$rowsresult['12']);
            rsort($arraymaiorgasto);
            $tresmaiores = array_slice($arraymaiorgasto,0,3);
            $somamaiorgasto = array_sum($tresmaiores);
            $mediamaiorgasto = $somamaiorgasto/3;
            $valornecessario = $mediamaiorgasto * $meses;
            $avaliasuplementacao = $total - $totalpago;
            if($avaliasuplementacao > $valornecessario)
            {
                $resposta = 'N - há disponibilidade de valores';
            }
            else{
                $suplementar = $valornecessario - $avaliasuplementacao;
                $resposta = 'S - Suplementar em: '.number_format($suplementar,2,',','.');
            }

        $psecretaria = $rowsresult['secretarias'];
        $punidade = $rowsresult['unidade'];
        $pficha = $rowsresult['ficha'];
        $pdotacao = $rowsresult['dotacao'];
        $pinicial = number_format($inicial,2,',','.');
        $psuplementos = number_format($somasuplementos,2,',','.');
        $panulacoes = number_format($somaanulacoes,2,',','.');
        $ptotal = number_format($total,2,',','.');
        $ptotalpago = number_format($totalpago,2,',','.');
        $pmediapaga = number_format($mediapaga,2,',','.');
        $psomamaiorgasto = number_format($somamaiorgasto,2,',','.');
        $pmediamaiorgasto = number_format($mediamaiorgasto,2,',','.');
        $presposta = utf8_decode($resposta);

        $pdf-> Cell(30,6, utf8_decode($psecretaria), 1.0, 'L', 0);
        $pdf-> Cell(30,6, utf8_decode($punidade), 1.0, 'L', 0);
        $pdf-> Cell(30,6, $pficha, 1.0, 'L', 0);
        $pdf-> Cell(30,6, $pdotacao, 1.0, 'L', 0);
        $pdf-> Cell(30,6, $pinicial, 1.0, 'L', 0);
        $pdf-> Cell(30,6, $psuplementos, 1.0, 'L', 0);
        $pdf-> Cell(30,6, $panulacoes, 1.0, 'L', 0);
        $pdf-> Cell(30,6, $ptotal, 1.0, 'L', 0);
        $pdf-> Cell(30,6, $ptotalpago, 1.0, 'L', 0);
        $pdf-> Cell(30,6, $pmediapaga, 1.0, 'L', 0);
        $pdf-> Cell(30,6, $psomamaiorgasto, 1.0, 'L', 0);
        $pdf-> Cell(30,6, $pmediamaiorgasto, 1.0, 'L', 0);
        $pdf-> Cell(30,6, $presposta, 1.0, 'L', 0);
        
        $pdf-> Ln (15);
        }

        mysqli_close ($conn);

// Mostramos o documento pdf
$pdf-> Output ('Suplementacao','I');


?>