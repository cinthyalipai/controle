<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');
?>

<?php
    if (isset($_POST['cadastro']) and $_POST['alteracao']==1)
        {
            $cadastro = $_POST['cadastro'];
            $tipo_alteracao = $_POST['alteracao'];
            $consultacadastro = "SELECT idcad from imovel where idcad = $cadastro ";
            $result = mysqli_query($conn, $consultacadastro);
            $numeroresult = mysqli_num_rows($result);

            if($numeroresult == 0)
            {
                echo "Não foi encontrado dados para o valor pesquisado. Corrija e tente novamente";
            }
            elseif($numeroresult == 1)
            {
                $hoje=date("Y-m-d");
                $ano = date('Y');
                $consultaidativo = "UPDATE pasta p
                                    JOIN (select p2.idpasta as id
                                            from pasta p2
                                            where p2.numcad=$cadastro and
                                                p2.at$ano like 'Ativo') as alteracao
                                    ON p.idpasta = alteracao.id
                                    SET p.at$ano = 'Inativo'";
                $resultconsultaid = mysqli_query($conn, $consultaidativo);
            if($resultconsultaid)
                {
                    echo "<br><br><br>";
                    echo "Foi realizada ".$resultconsultaid." alteração. O cadastro ".$cadastro." foi definido como Inativo";

                $sql5 = "INSERT INTO info (codinfo, dia, info) VALUES ('".$cadastro."','".$hoje."', 'Cadastro alterado para inativo no ano de ".$ano." pelo usuário ".$_SESSION['UsuarioNome']."')";
                $result5 = mysqli_query($conn, $sql5);
                } 
            }
        }
    elseif(isset($_POST['ano']) and $_POST['alteracao']==2)
        {
            $anoselec = $_POST['ano'];
            $tipo_alteracao = $_POST['alteracao'];
            $anoposterior = $anoselec + 1;

            $criatemp = "CREATE TEMPORARY TABLE temp 
                ( idtemp int(10) unsigned NOT NULL AUTO_INCREMENT,
                  codpasta int(10) unsigned NOT NULL,
                  ano int(10) unsigned NOT NULL DEFAULT '$anoposterior',
                  PRIMARY KEY (idtemp)
                  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
            $result_criatemp = mysqli_query($conn, $criatemp);

            //altera todos em lote
            $alteralote = "UPDATE pasta       
                            SET at$anoposterior='Ativo'
                            WHERE at$anoselec='Ativo'";
            $resulta_alteracao=mysqli_query($conn, $alteralote);

            $consultaatualizacao = "SELECT numcad, at$anoselec as atual, at$anoposterior as posterior 
                                    from pasta 
                                    where at$anoposterior='Ativo'";
            $result = mysqli_query($conn, $consultaatualizacao);

            //cria tabela temporaria para passar valores
            $inserttemp = "INSERT INTO temp (codpasta)
                        (select idpasta
                        from pasta
                        where at$anoposterior='Ativo')";
            $result_insertemp = mysqli_query($conn, $inserttemp);
            

            //insere na tabela valores
            $inserenovovalores = "INSERT INTO valores (codpasta, ano)
                                    select codpasta, ano
                                    from temp";
            $resultvalores = mysqli_query($conn, $inserenovovalores);

            //insere na tabela consumo
            $inserenovoconsumo = "INSERT INTO consumo (codpasta, ano)
                                    select codpasta, ano
                                    from temp";
            $resultconsumo = mysqli_query($conn, $inserenovoconsumo);

            // $contaalteracoes = "SELECT COUNT(at$anoposterior) 
            //                     FROM pasta
            //                     WHERE at$anoposterior='Ativo'";
            // $result_contaalteracoes = mysqli_query($conn, $contaalteracoes);
            // $numcadastros = mysqli_fetch_row($result_contaalteracoes);

            // echo "O ano de ".$anoposterior. " foi atualizado. ".$numcadastros. " cadastros foram alterados.";
            echo "<br><br>";
            echo "O ano de ".$anoposterior. " foi atualizado. ";
         }
?>