<?php

include ('../connection/conexao.php');
include ('../semae/barramenu.php');

$tiposec = mysqli_query($conn, "SELECT idsecretaria, secretarias FROM secretarias");
$tipound = mysqli_query($conn, "SELECT id, unidade FROM unidades");
$pasta = "SELECT * FROM pasta";

?>
<head>
    <meta charset="utf-8">
    <title>Pesquisa Por Secretaria</title>
</head>
<body>
    <br>
    <form name="pesquisa" method="POST" action="pesquisapredios.php">
        <table>
            <th colspan='2'>Pesquisa de Prédios Ativos por Secretaria e Ano</th>
            <tr>
                <td>Secretaria:</td>
                <td>
                    <select name="nome_sec"> 
                        <option>Selecione Secretaria</option>
                        <?php while($secretaria = mysqli_fetch_array($tiposec)) 
                        { ?> 
                            <option value="<?php echo $secretaria['idsecretaria'] ?>"><?php echo $secretaria['secretarias'] ?></option> 
                        <?php } ?> 
                    </select>
                </td>
            </tr>
            <tr>
                <td>Unidade:</td>
                <td>
                <select name="nome_und"> 
                    <option>Selecione Unidade</option>
                    <?php while($unidade = mysqli_fetch_array($tipound)) 
                    { ?> 
                        <option value="<?php echo $unidade['id'] ?>"><?php echo $unidade['unidade'] ?></option> 
                    <?php } ?> 
                </select>
            </td> 
            </tr>
            <tr>
                <td>Ano:</td>
                <td><input type="text" name="ano" id="ano" maxlength="4" required/></td>
            </tr>
            <tr>
                <td align="right" colspan="2"><input type="submit" value="Pesquisar"></td>
            </tr>
        </table>
    </form>

<?php

if (empty($_POST['nome_sec']) and empty($_POST['nome_und']) and empty($_POST['ano']))

    echo "Inserir dados para a pesquisa";

elseif (!empty($_POST['nome_sec']) and empty($_POST['nome_und']) and empty($_POST['ano']))

    echo "Favor preencher todos os dados";

elseif (empty($_POST['nome_sec']) and !empty($_POST['nome_und']) and empty($_POST['ano']))

    echo "Favor preencher todos os dados";

elseif (empty($_POST['nome_sec']) and empty($_POST['nome_und']) and !empty($_POST['ano']))

echo "Favor preencher todos os dados";    

elseif (!empty($_POST['nome_sec']) and !empty($_POST['nome_und']) and !empty($_POST['ano']))
{ 

$nomesec = $_POST['nome_sec'];
$nomeund = $_POST['nome_und'];
$ano = $_POST['ano'];

echo "<br>";
echo"<table border='1'>";
echo"<tr>";
    echo"<td><b>Cadastro</b></td>";              
    echo"<td><b>Hidrometro</b></td>"; 
    echo"<td><b>Tipo Contrato</b></td>";             
    echo"<td><b>Proprietario Imovel</b></td>";
    echo"<td><b>Nome do Predio</b></td>";
    echo"<td><b>Endereco</b></td>";
    echo"<td><b>Numero</b></td>";          
    echo"<td><b>Bairro</b></td>";
    echo"<td><b>Secretaria</b></td>";
    echo"<td><b>Unidade</b></td>";
    echo"<td><b>Ref Cobrança</b></td>";
    echo"<td><b>Funcionamento em ".$ano."</b></td>";
echo"</tr>";

$sqlpesquisa = "SELECT i.idcad, i.numhidro, t.tipo, i.proprietario, i.denomina, r.ruas, i.numero, b.bairros, s.secretarias, u.unidade, f.referencia, p.at$ano as funcionamento
                FROM imovel i, tipoprop t, ruas r, bairros b, pasta p, secretarias s, unidades u, referencia f
                WHERE i.codtipoprop = t.id AND
                        i.codlogradouro = r.idrua AND
                        i.codbairro = b.idbairro AND
                        p.numcad = i.idcad AND
                        p.codsec = s.idsecretaria AND
                        p.codund = u.id AND
                        p.codref = f.idref AND
                        p.codsec = $nomesec AND
                        p.codund = $nomeund AND
                        p.at$ano like 'Ativo'
                ORDER BY p.at$ano ASC, f.referencia DESC, i.idcad ASC";
                
$resultado_pesquisa = mysqli_query($conn, $sqlpesquisa);
$rows_pesquisa = mysqli_fetch_array($resultado_pesquisa);
if($rows_pesquisa >0){
    $idcad=$rows_pesquisa['idcad'];
    $hidrometro=$rows_pesquisa['numhidro'];
    $tipo_prop=$rows_pesquisa['tipo'];
    $nome_prop=$rows_pesquisa['proprietario'];
    $denomina=$rows_pesquisa['denomina'];
    $logradouro=$rows_pesquisa['ruas'];
    $numero=$rows_pesquisa['numero'];
    $bairro=$rows_pesquisa['bairros'];
    $secretaria=$rows_pesquisa['secretarias'];
    $unidade=$rows_pesquisa['unidade'];
    $referencia=$rows_pesquisa['referencia'];
    $funcionamento=$rows_pesquisa['funcionamento'];
        do
        {
            echo "<tr>";
            echo "<td>".$rows_pesquisa['idcad']."</td>";
            echo "<td>".$rows_pesquisa['numhidro']."</td>";
            echo "<td>".$rows_pesquisa['tipo']."</td>";
            echo "<td>".$rows_pesquisa['proprietario']."</td>";
            echo "<td>".$rows_pesquisa['denomina']."</td>";
            echo "<td>".$rows_pesquisa['ruas']."</td>";
            echo "<td>".$rows_pesquisa['numero']."</td>";
            echo "<td>".$rows_pesquisa['bairros']."</td>";
            echo "<td>".$rows_pesquisa['secretarias']."</td>";
            echo "<td>".$rows_pesquisa['unidade']."</td>";
            echo "<td align='center'>".$rows_pesquisa['referencia']."</td>";
            echo "<td align='center'>".$rows_pesquisa['funcionamento']."</td>";
            echo "</tr>";
        } while($rows_pesquisa = mysqli_fetch_array($resultado_pesquisa));
} 
else {
    echo "<h3 align='center'> Não foram encontrados valores para os dados pesquisados.</h3>";
    } 
    
}
 ?>

</body>