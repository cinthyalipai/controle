<head>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
  <table class="login">
      <tr>
        <td><a href=../logout.php>Logout</a></td>
    </tr>
  </table>
</body>