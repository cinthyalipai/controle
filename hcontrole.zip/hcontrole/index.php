<head>
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
</head>

<!-- <body class=center-form>
<div class=center-form> -->
<body>
  <div class="container">
    <div class="row g-5 mt-2 position-absolute start-50 top-50 translate-middle">
      <!-- Formulário de Login -->
      <form action="validacao.php" method="post">
        <table>
          <th colspan="2" class="text-center text-dark display-6">Sistema Interno de Controles</th>
          <tr>
            <td class="lead">Usuário:</td>
            <td><input type="text" class="form-control mt-4" name="usuario" id="txUsuario" maxlength="25" /></td>
          </tr>
          <tr>
            <td class="lead">Senha:</td>
            <td><input type="password" class="form-control mt-1" name="senha" id="txSenha" /></td>
          </tr>
        </table>
          <button class="btn btn-outline-secondary d-grid mt-2">Entrar</button>
          <p class="mt-3"><a class="text-primary" href="cadastrausuario.php">Ainda não tenho cadastro</a></p>
          <p class="mt-3"><a class="text-danger" href="alterausuario.php">Recuperar Senha</a></p>
      </form>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>