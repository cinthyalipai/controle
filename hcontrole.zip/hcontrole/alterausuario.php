<?php
    include ('connection/conexao.php');
?>

<head>
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
  <meta charset="utf-8">
</head>

<div class="container">
    <div class="row g-5 mt-2 position-absolute start-50 top-50 translate-middle">
        <form name="cadastro"  method="POST" action="">
            <table class="table table-bordered ">
                <tr>
                    <th class="text-center text-dark display-6">Alteração de Senha dos Usuários</th>
                </tr>
                <tr>
                    <td class="lead">Usuário:
                    <input type="text" class="form-control mt-1" name="user" maxlength="10" required>
                    </td>
                </tr>
                <tr>
                    <td class="lead">E-mail:
                    <input type="text" class="form-control mt-1" name="email" maxlength="100" required>
                    </td>
                </tr>
                <tr>
                    <td class="lead">Nova Senha:
                    <input type="password" class="form-control mt-1" name="senha" maxlength="10" required>
                    </td>
                </tr>
                <tr>
                    <td class="lead">Confirme a Senha:
                    <input type="password" class="form-control mt-1" name="confirmasenha" maxlength="10" required>
                    </td>
                </tr>
            </table>
            <button class="btn btn-outline-success d-grid mt-2">Alterar</button>
        </form>

<?php
    if (isset($_POST['senha']))
    {
        if ($_POST['senha']<>$_POST['confirmasenha'])
        {
            echo "<p class='text-danger'>Os campos Senha e Confirmar Senha divergem. Favor rever as informações digitadas.</p>";
        }
        else
        {
            $email = $_POST['email'];
            $usuario = $_POST['user'];
            $senha = $_POST['senha'];
            $confirmasenha = $_POST['confirmasenha'];
            $hoje=date('Y-m-d H:i');
            $cripto = sha1($senha);

            $consultausuario = "SELECT usuario from usuarios where usuario='".$usuario."' and email='".$email."'";
            $resultconsultausuario = mysqli_query($conn, $consultausuario);
            $contausuarios = mysqli_num_rows($resultconsultausuario);

            if($contausuarios > 0)
            {
                echo "<p class='text-danger'>O usuario ".$usuario." não foi localizado! Favor reveja o usuário digitado e o email informado.</p>";
            }
            else
            {
                $alterasenha = "UPDATE usuarios 
                                SET senha = '".$cripto."', 
                                    cadastro = '".$hoje."'
                                WHERE usuario = '".$usuario."'";
                $result_alterasenha = mysqli_query($conn, $alterasenha); 

                echo "<p class='text-muted bg-light p-2'>A senha do usuário <b>".$usuario."</b> foi cadastrado com sucesso. Realize seu login no portal</i></p>";

                header ("Refresh: 2; url =index.php");
            }

        } 

            
    }


    
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>