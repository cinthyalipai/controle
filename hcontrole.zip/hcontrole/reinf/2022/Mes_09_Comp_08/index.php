<html>
    <head>
        <meta charset="utf-8">
    </head>
    <title>
        Relatorio Dados REINF
    </title>
    <body>
        <?php
        $arquivo = "todos.xml";
        if (file_exists($arquivo)){
        $xml = simplexml_load_file('todos.xml'); ?>
        <table border='1'>
            <th>Periodo de Apuração:</th>
            <th>Núm Inscrição (Raiz CNPJ):</th>
            <tr align='center'>
                <td><?php echo $xml->evtServTom->ideEvento->perApur; ?></td>
                <td><?php echo $xml->evtServTom->ideContri->nrInsc; ?></td>
            </tr>
        </table>
        <p><a href='../../index.html'>Voltar</a></p>
        <br><br><br>
        <table border='1'>
            <th>Num:</th>
            <th>Num Insc Estab:</th>
            <th>CNPJ Prestador:</th>
            <th>Cont CPRB?:</th>
            <th>Vlr Total Bruto:</th>
            <th>Total Base de Ret:</th>
            <th>Vlr Total Retido:</th>
            <th>Num NF:</th>
            <th>Data NF:</th>
            <th>Vlr Bruto NF:</th>
            <th>Vlr Base Cálculo Retenção:</th>
            <th>Vlr Retido:</th>
            <?php 
            $i = 1;
            foreach($xml->evtServTom->infoServTom->ideEstabObra as $obra) {
            $j = $i++;
            echo '<tr>'; 
                echo '<td>'.$j.'</td>';
                echo '<td align="right">'.$obra->nrInscEstab.'</td>'; 
            foreach($obra->idePrestServ as $prestador) {
                echo '<td>'.$prestador->cnpjPrestador.'</td>';
                echo '<td align="center">'.$prestador->indCPRB.'</td>';
                echo '<td>'.$prestador->vlrTotalBruto.'</td>';
                echo '<td>'.$prestador->vlrTotalBaseRet.'</td>';
                echo '<td>'.$prestador->vlrTotalRetPrinc.'</td>'; 
                echo '<td>'.$prestador->nfs->numDocto.'</td>';
                echo '<td>'.$prestador->nfs->dtEmissaoNF.'</td>';
                echo '<td>'.$prestador->nfs->vlrBruto.'</td>';
                echo '<td>'.$prestador->nfs->infoTpServ->vlrBaseRet.'</td>';
                echo '<td>'.$prestador->nfs->infoTpServ->vlrRetencao.'</td>';
            }} 
            echo '</tr>';}
            else { 
                echo "O Mês ainda não está em avaliação.";
                echo "<p><a href='../../index.html'>Voltar</a></p>";
                }
            ?>
        </table>
    </body>
     <form action='download.php' method="get"> <!--verificar como fzr o download -->
        <input type='button' value='Download' name='enviar'>
     </form>           

</html>