<?php
    if ('$iddespfisica' == null OR empty('$iddespfisica') OR empty($_POST)){
        echo "Favor Selecionar uma das opções";
    }
    $iddespfisica = $_POST['iddespfisica'];
    print_r($iddespfisica); echo "\n";

    if ('$iddespfisica' == '1'){
        echo "RPCI";
    } elseif ('$iddespfisica' ==2) {
        echo "Locação";
    //else echo "Prêmio";
    } elseif ('$iddespfisica' ==3){
        echo "Prêmio";
    } else {
        echo "Selecionar uma das opções";
    }
?>