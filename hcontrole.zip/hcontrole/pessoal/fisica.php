<?php
    include ('connection/conexao.php');
    include ('restrito.php');
?>

<form action="armazenafisica.php" method="post">
    <table border='1' align="center">
        <tr>
            <th>Tipo de Cadastro </th>
            <td><input type="radio" name="iddespfisica" value='1'>RPCI</td>
            <td><input type="radio" name="iddespfisica" value='2'>Locação</td>
            <td><input type="radio" name="iddespfisica" value='3'>Prêmios</td>
            <td><input type="submit" name ="Selecionar" value="enviar"></td>
        </tr>
    </table>
</form>

<?php
    if ('$iddespfisica' == null OR empty('$iddespfisica') OR empty($_POST)){
        echo "Favor Selecionar uma das opções";
    }
?>

